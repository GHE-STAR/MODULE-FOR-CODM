/* KOYRI STRETCH — WebUI core bridge (readable source).
 *
 * The only file that talks to the root manager. Two layers:
 *
 *   exec(cmd)        runs a shell command through the manager bridge
 *                    (window.ksu on KernelSU / KernelSU-Next / APatch /
 *                    SukiSU, window.mmrl on MMRL WebUI X) and resolves
 *                    { errno, stdout, stderr }. The callback-global pattern
 *                    plus the promise variant covers every manager flavour;
 *                    everything times out so a dead bridge can never hang
 *                    the page.
 *
 *   *Cmd(...)        builders that return shell snippets. They never run
 *                    anything themselves — app.js composes them and execs
 *                    once, so one INJECT is one shell round-trip.
 *
 * Every builder validates its inputs before interpolating them into a command,
 * and every write is atomic (tmp file + chmod + mv), so a caller that forgets a
 * check cannot end up with shell injection or a half-written target.
 *
 * Config layout under /data/adb/koyri_stretch:
 *
 *   <package>                 koyri.stretch=<NxM>      (required, marks a target)
 *   <package>.koyri-touch     koyri.touch=0            (absent = remap on)
 *   <package>.koyri-portrait  koyri.portrait=1         (absent = landscape only)
 *   <package>.koyri-cutout    koyri.cutout=1           (absent = keep insets)
 *
 * The native companion reads those same files (koyri_stretch_module.cpp), the
 * CLI writes them (stretch.sh) and this file writes them — one format, no
 * duplication of the ratio allowlist anywhere.
 */
window.KSCore = (function () {
  'use strict';

  var DIR = '/data/adb/koyri_stretch';
  var MODDIR = '/data/adb/modules/koyri_stretch';
  var TIMEOUT_MS = 15000;
  var MAX_RATIO_SIDE = 32;
  var seq = 0;

  /* ---------------------------------------------------------------- bridge */

  function bridgeKind() {
    if (window.ksu && typeof window.ksu.exec === 'function') return 'ksu';
    if (window.mmrl && typeof window.mmrl.exec === 'function') return 'mmrl';
    return null;
  }

  function exec(cmd) {
    return new Promise(function (resolve, reject) {
      var kind = bridgeKind();
      if (!kind) { reject(new Error('no bridge')); return; }
      var bridge = kind === 'ksu' ? window.ksu : window.mmrl;
      var name = '__koyri_cb_' + Date.now() + '_' + (++seq);
      var done = false;

      function finish(errno, stdout, stderr) {
        if (done) return;
        done = true;
        try { delete window[name]; } catch (e) { window[name] = undefined; }
        resolve({ errno: errno | 0, stdout: stdout || '', stderr: stderr || '' });
      }

      window[name] = function (errno, stdout, stderr) { finish(errno, stdout, stderr); };

      var ret;
      try {
        ret = bridge.exec(cmd, '{}', name);
      } catch (e) {
        done = true;
        reject(e);
        return;
      }
      // Some managers answer with a promise instead of calling the global.
      if (ret && typeof ret.then === 'function') {
        ret.then(function (res) {
          var out = res;
          if (typeof out === 'string') {
            try { out = JSON.parse(out); } catch (e) { out = {}; }
          }
          out = out || {};
          finish(out.errno >= 0 ? out.errno : -1, out.stdout, out.stderr);
        }).catch(function (e) {
          if (!done) { done = true; reject(e); }
        });
      }
      setTimeout(function () {
        if (done) return;
        done = true;
        try { delete window[name]; } catch (e) { window[name] = undefined; }
        reject(new Error('timeout'));
      }, TIMEOUT_MS);
    });
  }

  function toast(message) {
    try {
      if (window.ksu && typeof window.ksu.toast === 'function') window.ksu.toast(message);
      else if (window.mmrl && typeof window.mmrl.toast === 'function') window.mmrl.toast(message);
    } catch (e) { /* cosmetic */ }
  }

  /* ----------------------------------------------------------- validation */

  /* Same rule the native companion (valid_package) and stretch.sh enforce:
   * letters, digits, underscore, dots; at least one dot; no leading/trailing
   * dot, no "..", 255 max. Anything else never reaches a command line. */
  function validPkg(name) {
    if (!name || typeof name !== 'string') return false;
    if (name.length > 255) return false;
    return /^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$/.test(name);
  }

  /* Any NxM with 1..32 per side, no leading zero. Same rule as the native
   * parser (koyri_stretch_parse) and the CLI (valid_ratio). */
  function validRatio(value) {
    if (!value || typeof value !== 'string') return false;
    var m = /^([0-9]{1,2})x([0-9]{1,2})$/.exec(value);
    if (!m) return false;
    var num = parseInt(m[1], 10);
    var den = parseInt(m[2], 10);
    if (!(num >= 1 && num <= MAX_RATIO_SIDE)) return false;
    if (!(den >= 1 && den <= MAX_RATIO_SIDE)) return false;
    return String(num) === m[1] && String(den) === m[2];
  }

  /* ------------------------------------------------------ command builders */

  /* One atomic writer, defined once per snippet: mkdir, tmp file, chmod, mv. */
  function preamble() {
    return [
      'D=' + DIR,
      'mkdir -p "$D" 2>/dev/null || { echo "cannot create $D" >&2; exit 1; }',
      'kw() {',
      '  t="$1.tmp.$$"',
      '  printf "%s\\n" "$2" > "$t" 2>/dev/null || { rm -f "$t"; return 1; }',
      '  chmod 644 "$t" 2>/dev/null',
      '  mv -f "$t" "$1" 2>/dev/null || { rm -f "$t"; return 1; }',
      '}'
    ];
  }

  function touchCmd(name, on) {
    var path = '"$D/' + name + '.koyri-touch"';
    if (on) return 'rm -f ' + path + ' 2>/dev/null';
    return 'kw ' + path + ' "koyri.touch=0" || { echo "touch switch failed" >&2; exit 1; }';
  }

  function portraitCmd(name, on) {
    var path = '"$D/' + name + '.koyri-portrait"';
    if (!on) return 'rm -f ' + path + ' 2>/dev/null';
    return 'kw ' + path + ' "koyri.portrait=1" || { echo "portrait switch failed" >&2; exit 1; }';
  }

  function cutoutCmd(name, on) {
    var path = '"$D/' + name + '.koyri-cutout"';
    if (!on) return 'rm -f ' + path + ' 2>/dev/null';
    return 'kw ' + path + ' "koyri.cutout=1" || { echo "cutout switch failed" >&2; exit 1; }';
  }

  /* Writes the whole per-target configuration in one shell round-trip.
   * `cfg` = { ratio, touch, portrait, cutout } — every field optional
   * except ratio. Returns '' when the input is not safe to run. */
  function saveTargetCmd(name, cfg) {
    if (!validPkg(name)) return '';
    cfg = cfg || {};
    var ratio = String(cfg.ratio || '');
    if (!validRatio(ratio)) return '';
    var touch = cfg.touch !== false;
    var portrait = cfg.portrait === true;
    var cutout = cfg.cutout === true;

    return preamble().concat([
      'kw "$D/' + name + '" "koyri.stretch=' + ratio + '" || { echo "target write failed" >&2; exit 1; }',
      // Sidecars from features this build no longer has (downscale tile, frame-rate
      // unlock): nothing reads them any more, so a save sweeps them instead of leaving
      // dead config behind.
      'rm -f "$D/' + name + '.koyri-scale" "$D/' + name + '.koyri-fps" 2>/dev/null',
      touchCmd(name, touch),
      portraitCmd(name, portrait),
      cutoutCmd(name, cutout),
      'echo "saved ' + name + ' ' + ratio +
        ' touch=' + (touch ? 'on' : 'off') +
        ' portrait=' + (portrait ? 'on' : 'off') +
        ' cutout=' + (cutout ? 'on' : 'off') + '"'
    ]).join('\n');
  }

  /* Remove a target and every sidecar, like stretch.sh remove. The legacy
   * .koyri-scale and .koyri-fps files are still swept: older builds wrote them. */
  function removeTargetCmd(name) {
    if (!validPkg(name)) return '';
    return [
      'D=' + DIR,
      'rm -f "$D/' + name + '" "$D/' + name + '.koyri-scale" "$D/' + name +
        '.koyri-touch" "$D/' + name + '.koyri-portrait" "$D/' + name + '.koyri-cutout"' +
        ' "$D/' + name + '.koyri-fps" 2>/dev/null',
      'echo "removed ' + name + '"'
    ].join('\n');
  }

  /* One pass over the config dir: "<pkg> <ratio> <touch> <portrait> <cutout>". */
  function listCmd() {
    return [
      'D=' + DIR,
      '[ -d "$D" ] || exit 0',
      'for f in "$D"/*; do',
      '  [ -f "$f" ] || continue',
      '  n=${f##*/}',
      '  case "$n" in .*|*.koyri-*) continue ;; esac',
      '  r=$(sed -n "s/^koyri[.]stretch=//p" "$f" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  [ -n "$r" ] || continue',
      '  t=$(sed -n "s/^koyri[.]touch=//p" "$D/$n.koyri-touch" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  [ "$t" = "0" ] || t=1',
      '  p=$(sed -n "s/^koyri[.]portrait=//p" "$D/$n.koyri-portrait" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  [ "$p" = "1" ] || p=0',
      '  c=$(sed -n "s/^koyri[.]cutout=//p" "$D/$n.koyri-cutout" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  [ "$c" = "1" ] || c=0',
      '  echo "$n $r $t $p $c"',
      'done'
    ].join('\n');
  }

  function logCmd() {
    return 'tail -n 200 ' + DIR + '/module.log 2>/dev/null || echo "(no module log yet)"';
  }

  /* Top-strip diagnosis. The Java runtime writes a probe line for the first taps of a session
   * and for the first taps inside the top 12% of the render surface, plus the activation line
   * that carries the surface origin and the touch scale. Comparing raw with the mapped point
   * tells a remap problem (mapped goes negative) from a window above us (no line at all, which
   * means the touch never reached the process -- SystemUI ate it). */
  function diagnoseCmd() {
    return [
      'echo "== touch probe =="',
      'logcat -d -s KoyriStretch 2>/dev/null | grep -E "edge-to-edge|active:|origin moved|touch: (DOWN|UP|MOVE|TOP-BAND|rescale|remap)" | tail -n 120',
      'echo "== module log =="',
      'tail -n 40 ' + DIR + '/module.log 2>/dev/null || echo "(no module log yet)"'
    ].join('\n');
  }

  function statusCmd() {
    return [
      'echo "model="$(getprop ro.product.model)',
      'echo "brand="$(getprop ro.product.brand)',
      'echo "android="$(getprop ro.build.version.release)',
      'echo "sdk="$(getprop ro.build.version.sdk)',
      'echo "abi="$(getprop ro.product.cpu.abilist)',
      // ro.serialno is empty for apps on Android 10+, but this block runs as root
      // and reads the property directly; ro.boot.serialno is the fallback on ROMs
      // that only populate the boot copy.
      's=$(getprop ro.serialno 2>/dev/null); [ -n "$s" ] || s=$(getprop ro.boot.serialno 2>/dev/null)',
      'echo "serial=$s"',
      // wm lives here, not in app.js: this file is the only place that builds shell, so the
      // whole status block is exercised by the self-test's `sh -n` pass.
      'echo "wm="$(wm size 2>/dev/null | tr -d " " | tr "\\n" "|")',
      // Every provider id in the wild, and both module roots: a module still sitting in
      // modules_update is "installed, pending reboot", which is exactly what a user who just
      // flashed it needs to see instead of a false "missing".
      'z=""',
      // Same roots check.sh walks: a KernelSU / APatch build keeps its module dirs
      // under its own prefix, and a status row that says "no zygisk" on a device that
      // is running Zygisk Next is worse than no row at all.
      'for b in /data/adb/modules /data/adb/modules_update /data/adb/ksu/modules /data/adb/ap/modules; do',
      '  [ -n "$z" ] && break',
      '  for id in zygisksu zygisk_next zygisknext neozygisk rezygisk; do',
      '    [ -d "$b/$id" ] && { z=$id; break; }',
      '  done',
      'done',
      'echo "zygisk=$z"',
      // A module that was just flashed still sits in modules_update until the reboot,
      // and an install can also live under a manager-specific prefix: reading only the
      // live path would call a pending install "not installed" while its WebUI is open.
      // Same roots check.sh walks.
      'mp=""',
      'for b in ' + MODDIR + ' /data/adb/modules_update/koyri_stretch /data/adb/ksu/modules/koyri_stretch /data/adb/ap/modules/koyri_stretch; do',
      '  [ -f "$b/module.prop" ] && { mp="$b/module.prop"; break; }',
      'done',
      'echo "modver="$(sed -n \'s/^version=//p\' "$mp" 2>/dev/null | head -n 1)',
      'echo "modcode="$(sed -n \'s/^versionCode=//p\' "$mp" 2>/dev/null | head -n 1)',
      'echo "moddir=${mp%/module.prop}"',
      // Same precedence as check.sh: SukiSU keeps the KernelSU layout so it is
      // tested first, Magisk last so a leftover /data/adb/magisk next to a
      // KernelSU install is not misreported as Magisk.
      'mgr=none',
      'if [ -d /data/adb/suki ]; then mgr=SukiSU',
      'elif [ -d /data/adb/ksu ] || [ -d /data/adb/ksud ]; then mgr=KernelSU',
      'elif [ -d /data/adb/ap ] || [ -d /data/adb/apd ]; then mgr=APatch',
      'elif [ -d /data/adb/magisk ]; then mgr=Magisk',
      'fi',
      'echo "mgr=$mgr"',
      // Count real target files only. The config dir also holds module.log and
      // module.log.old, which a plain `ls | grep -v koyri-` counted as targets.
      'c=0',
      'for f in ' + DIR + '/*; do',
      '  [ -f "$f" ] || continue',
      '  case "${f##*/}" in .*|*.koyri-*|module.log*) continue ;; esac',
      '  c=$((c + 1))',
      'done',
      'echo "targets=$c"'
    ].join('\n');
  }

  function wmSizeCmd() {
    return 'wm size 2>/dev/null | tail -n 1';
  }

  /* Clears the display-size override. `wm size WxH` — and every "WM Size"
   * module or app built on top of it — persists Settings.Global.display_size,
   * which survives a reboot and keeps the panel in a letterboxed window that
   * the stretch cannot line up with. `wm size reset` deletes that setting;
   * the trailing read is emitted in the same shape as the status row so the
   * same parser fills both the Device tile and the reset card. */
  function wmResetCmd() {
    return [
      'wm size reset 2>&1',
      'wm size 2>/dev/null | tr -d " " | tr "\\n" "|"'
    ].join('\n');
  }

  /* Foreground package of whatever is on screen right now, plus the fallback
   * dumpsys shapes older ROMs use. app.js picks the first package-looking token. */
  function detectCmd() {
    return [
      'dumpsys activity activities 2>/dev/null | grep -m1 topResumedActivity',
      'dumpsys window 2>/dev/null | grep -m1 mCurrentFocus',
      'dumpsys activity 2>/dev/null | grep -m1 mResumedActivity'
    ].join('\n');
  }

  function packagesCmd() {
    return 'pm list packages 2>/dev/null | sed \'s/^package://\' | sort';
  }

  function forceStopCmd(name) {
    if (!validPkg(name)) return '';
    return 'am force-stop ' + name + ' 2>/dev/null || true';
  }

  /* Backup goes through the shell so the export survives a reinstall even when
   * the WebView blocks blob/file downloads. base64 keeps JSON quoting out of
   * the shell entirely. */
  function exportCmd() {
    return [
      'D=' + DIR,
      '[ -d "$D" ] || exit 0',
      'for f in "$D"/*; do',
      '  [ -f "$f" ] || continue',
      '  n=${f##*/}',
      '  case "$n" in .*|*.koyri-*) continue ;; esac',
      '  r=$(sed -n "s/^koyri[.]stretch=//p" "$f" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  [ -n "$r" ] || continue',
      '  t=$(sed -n "s/^koyri[.]touch=//p" "$D/$n.koyri-touch" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  p=$(sed -n "s/^koyri[.]portrait=//p" "$D/$n.koyri-portrait" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  c=$(sed -n "s/^koyri[.]cutout=//p" "$D/$n.koyri-cutout" 2>/dev/null | head -n 1 | tr -d "\\r")',
      '  echo "$n|$r|${t:-1}|${p:-0}|${c:-0}"',
      'done'
    ].join('\n');
  }

  return {
    DIR: DIR,
    MODDIR: MODDIR,
    MAX_RATIO_SIDE: MAX_RATIO_SIDE,
    exec: exec,
    toast: toast,
    validPkg: validPkg,
    validRatio: validRatio,
    saveTargetCmd: saveTargetCmd,
    removeTargetCmd: removeTargetCmd,
    listCmd: listCmd,
    logCmd: logCmd,
    diagnoseCmd: diagnoseCmd,
    statusCmd: statusCmd,
    wmSizeCmd: wmSizeCmd,
    wmResetCmd: wmResetCmd,
    detectCmd: detectCmd,
    packagesCmd: packagesCmd,
    forceStopCmd: forceStopCmd,
    exportCmd: exportCmd,
    /* Kept for scripts written against the v1.6 API: ratio-only save. */
    writeTargetCmd: function (name, ratio) {
      return saveTargetCmd(name, { ratio: ratio, touch: true });
    }
  };
})();
