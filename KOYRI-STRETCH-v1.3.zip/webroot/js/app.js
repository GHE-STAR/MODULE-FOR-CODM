/* KOYRI STRETCH — WebUI application layer.
 *
 * One page, two jobs:
 *
 *   editor    pick a package + a ratio (+ the three per-target switches,
 *             owned by switches.js) and write it through the root manager
 *             bridge in ONE shell round-trip.
 *
 *   inspector show what the module will actually do: device facts, a geometry
 *             preview that uses the exact stretch rule the native hook and the
 *             Java runtime use, the current target list and the module log.
 *
 * Every shell command comes from core.js (KSCore.*Cmd) — this file never
 * builds a command by hand, so package/ratio validation exists in exactly one
 * place. Nothing here polls: status, targets and log refresh on load, on
 * demand, and after a write.
 */
(function () {
  'use strict';

  var K = window.KSCore;
  if (!K) return;

  /* ------------------------------------------------------------ dom helpers */

  function $(id) {
    return document.getElementById(id);
  }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function clear(node) {
    if (node) node.innerHTML = '';
  }

  function on(node, ev, fn) {
    if (node) node.addEventListener(ev, fn);
  }

  /* ---------------------------------------------------------------- state */

  var S = {
    bridge: false,
    device: {
      model: '', brand: '', android: '', sdk: '', abi: '', serial: '',
      zygisk: '', modver: '', modcode: '', targets: '', wm: '', mgr: '', moddir: ''
    },
    targets: {},          // package -> { ratio, touch, portrait, cutout }
    pkg: '',
    ratio: '16x9',
    orientation: 'landscape',
    packages: null,       // cached `pm list packages` result
    previewUrl: '',
    logOpen: false
  };

  /* Presets only. Any other NxM (1..32 per side) goes through the custom
   * field — the module accepts the same range everywhere, so the presets are
   * convenience, not an allowlist. */
  /* Ordered widest to narrowest, so the top row is the thinnest/tallest look and
   * the list walks down to portrait. The grid fills 4 columns on wide screens,
   * so sixteen tiles land as four even rows. */
  var RATIOS = [
    { v: '25x9', name: '25:9', sub: 'max tall' },
    { v: '24x9', name: '24:9', sub: 'taller' },
    { v: '23x9', name: '23:9', sub: 'tall+' },
    { v: '22x9', name: '22:9', sub: 'tall' },
    { v: '21x9', name: '21:9', sub: 'ultrawide' },
    { v: '20x9', name: '20:9', sub: 'tall phone' },
    { v: '2x1', name: '2:1', sub: 'ultrawide' },
    { v: '16x9', name: '16:9', sub: 'widescreen' },
    { v: '16x10', name: '16:10', sub: 'tablet wide' },
    { v: '3x2', name: '3:2', sub: 'laptop' },
    { v: '4x3', name: '4:3', sub: 'classic' },
    { v: '5x4', name: '5:4', sub: 'square-ish' },
    { v: '10x9', name: '10:9', sub: 'narrow' },
    { v: '1x1', name: '1:1', sub: 'square' },
    { v: '3x4', name: '3:4', sub: 'portrait classic' },
    { v: '9x16', name: '9:16', sub: 'portrait' },
    { v: '', name: 'DEFAULT', sub: 'real aspect', restore: true }
  ];

  /* Safety ceiling for the render buffer. Mirrors kMaxBufferSide in Boot.java and
   * koyri_buffer_hook.cpp: a wide ratio on a tall window can ask for a buffer no panel can
   * show, so both sides scale down together and the aspect survives. */
  var MAX_BUFFER_SIDE = 4096;

  var INJECT_STEPS = [
    'checking package',
    'writing target',
    'applying switches',
    'force-stopping game',
    'finishing up'
  ];

  /* The wm size reset runs its overlay off a fixed clock, so the bar walks
   * these in step with the five seconds the button promises. */
  var WM_RESET_STEPS = [
    'reading wm size',
    'clearing override',
    'resetting display',
    're-reading panel',
    'finishing up'
  ];

  /* -------------------------------------------------------------- feedback */

  var toastTimer = null;

  function toast(message) {
    var node = $('toast');
    if (!node) return;
    node.textContent = String(message || '');
    node.classList.add('show');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      node.classList.remove('show');
    }, 2600);
  }

  function setStatus(kind, text) {
    var pill = $('statusPill');
    if (pill) {
      pill.className = 'status-pill' + (kind ? ' is-' + kind : '');
    }
    var label = $('statusText');
    if (label) label.textContent = text;
  }

  /* ---------------------------------------------------------------- bridge */

  function bridgePresent() {
    if (window.ksu && typeof window.ksu.exec === 'function') return true;
    if (window.mmrl && typeof window.mmrl.exec === 'function') return true;
    return false;
  }

  function showBanner(title, sub) {
    var banner = $('bridgeBanner');
    if (!banner) return;
    var t = $('bannerTitle');
    var s = $('bannerSub');
    if (t) t.textContent = title;
    if (s) s.textContent = sub || '';
    banner.hidden = false;
  }

  function hideBanner() {
    var banner = $('bridgeBanner');
    if (banner) banner.hidden = true;
  }

  function run(cmd) {
    return K.exec(cmd).catch(function (err) {
      toast(err && err.message === 'timeout' ? 'shell timed out' : 'shell unavailable');
      return { errno: -1, stdout: '', stderr: '' };
    });
  }

  /* Parses `key=value` lines (core.js statusCmd layout) into an object. */
  function parseKv(text) {
    var out = {};
    String(text || '').split('\n').forEach(function (line) {
      var i = line.indexOf('=');
      if (i <= 0) return;
      out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    });
    return out;
  }

  /* ---------------------------------------------------------------- device */

  function refreshStatus() {
    // statusCmd() already emits the wm row; this file never builds shell by hand.
    var cmd = K.statusCmd();
    return run(cmd).then(function (res) {
      if (res.errno !== 0) {
        setStatus('err', 'NO BRIDGE');
        return;
      }
      var kv = parseKv(res.stdout);
      S.device.model = kv.model || '';
      S.device.brand = kv.brand || '';
      S.device.android = kv.android || '';
      S.device.sdk = kv.sdk || '';
      S.device.abi = kv.abi || '';
      S.device.serial = kv.serial || '';
      S.device.zygisk = kv.zygisk || '';
      S.device.modver = kv.modver || '';
      S.device.modcode = kv.modcode || '';
      S.device.targets = kv.targets || '';
      S.device.wm = kv.wm || '';
      S.device.mgr = kv.mgr || '';
      S.device.moddir = kv.moddir || '';
      renderStatus();
      paintWmCard();
      renderPreview();
      paintStatusPill();
    });
  }

  var ZYGISK_LABELS = {
    zygisksu: 'Zygisk Next',
    zygisk_next: 'Zygisk Next (legacy id)',
    zygisknext: 'Zygisk Next (legacy id)',
    neozygisk: 'NeoZygisk',
    rezygisk: 'ReZygisk'
  };

  function zygiskState() {
    var z = String(S.device.zygisk || '');
    if (!z) return { kind: 'err', text: 'missing', note: 'No Zygisk provider found. On KernelSU / KernelSU-Next / APatch / SukiSU install Zygisk Next, NeoZygisk or ReZygisk; on Magisk enable Settings > Zygisk and reboot.' };
    var label = ZYGISK_LABELS[z] || z;
    return { kind: 'ok', text: label, note: label + ' detected. Module loads normally.' };
  }

  function paintStatusPill() {
    if (!S.bridge) {
      setStatus('err', 'NO BRIDGE');
      return;
    }
    var z = zygiskState();
    if (z.kind === 'ok') setStatus('ok', 'LINKED');
    else setStatus('warn', 'NO ZYGISK');
  }

  /* `wm size` prints "Physical size: WxH" and, only when something changed it,
   * "Override size: WxH". Natural size and override are different facts and the
   * Device card shows both, so the card never has to explain itself.
   *
   * core.js strips spaces out of the status row, so the space between the label
   * and the colon can be gone by the time this runs: match it optionally or a
   * real override reads as "none". */
  function wmParts(text) {
    var wm = String(text === undefined ? (S.device.wm || '') : (text || ''));
    var phys = /Physical\s*size:\s*(\d+)\s*x\s*(\d+)/i.exec(wm);
    var over = /Override\s*size:\s*(\d+)\s*x\s*(\d+)/i.exec(wm);
    return {
      natural: phys ? phys[1] + 'x' + phys[2] : '',
      override: over ? over[1] + 'x' + over[2] : ''
    };
  }

  /* Zygisk loads zygisk/<abi>.so, so the first ARM abi the device lists is the
   * one that decides which library is used — not the whole abilist. Same pick
   * as check.sh and the installer. */
  function mainAbi() {
    var list = String(S.device.abi || '').split(/[\s,]+/);
    for (var i = 0; i < list.length; i++) {
      if (/^(arm64-v8a|armeabi-v7a)$/.test(list[i])) return list[i];
    }
    return list[0] || 'unknown';
  }

  function renderStatus() {
    var grid = $('statusGrid');
    if (!grid) return;
    clear(grid);

    var d = S.device;
    var z = zygiskState();
    var wm = wmParts();
    var targets = parseInt(d.targets, 10) || 0;
    var hasMgr = d.mgr && d.mgr !== 'none';
    /* Most ROMs already bake the brand into ro.product.model ("TECNO CM5" with
     * brand "TECNO"), so joining blindly prints the brand twice. */
    var phone = [d.brand, d.model].filter(Boolean).join(' ') || 'unknown';
    if (d.brand && d.model && d.model.toLowerCase().indexOf(d.brand.toLowerCase()) === 0) {
      phone = d.model;
    }

    /* One tile per fact, hero tile first. Nothing is explained below the grid:
     * every value that needs a caveat carries it in its own tile. */
    var rows = [
      { k: 'phone', v: phone, row: 'wide hero' },
      { k: 'android', v: (d.android || '?') + (d.sdk ? ' · SDK ' + d.sdk : '') },
      { k: 'abi', v: mainAbi(), cls: /arm64-v8a|armeabi-v7a/.test(d.abi) ? '' : 'bad' },
      { k: 'serial', v: d.serial || 'not exposed', cls: d.serial ? 'mono' : 'dim' },
      { k: 'zygisk', v: z.kind === 'ok' ? z.text : 'missing · install Zygisk Next',
        cls: z.kind === 'ok' ? 'good' : 'bad' },
      { k: 'module', v: d.modver ? (d.modcode ? d.modver + ' · ' + d.modcode : d.modver) : 'not installed',
        cls: d.modver ? 'good' : 'bad' },
      { k: 'root manager', v: hasMgr ? d.mgr : 'not detected', cls: hasMgr ? '' : 'dim' },
      { k: 'display', v: wm.natural || 'unknown', cls: wm.natural ? '' : 'dim' },
      { k: 'wm override', v: wm.override || 'none', cls: wm.override ? 'mid' : 'dim' },
      { k: 'targets', v: String(targets), cls: targets ? '' : 'dim' },
      { k: 'module dir', v: d.moddir || 'not resolved', row: 'wide', cls: d.moddir ? 'mono' : 'dim' }
    ];

    rows.forEach(function (row) {
      var box = el('div', 'kv-row' + (row.row ? ' ' + row.row : ''));
      box.appendChild(el('span', 'kv-k', row.k));
      box.appendChild(el('span', 'kv-v' + (row.cls ? ' ' + row.cls : ''), row.v));
      grid.appendChild(box);
    });
  }

  /* --------------------------------------------------------- wm size reset */

  /* The only control on this page that changes a system setting: it deletes the
   * persisted display_size override a "WM Size" module or app leaves behind.
   * The card and the Device tile read the same `wm size` row, so they can never
   * disagree about whether an override is still sitting on the panel. */
  var WM_RESET_MS = 5000;

  function fmtSize(value) {
    return String(value || '').replace('x', '\u00d7');
  }

  function paintWmCard() {
    var state = $('wmState');
    if (!state) return;
    var wm = wmParts();
    if (!S.device.wm) {
      state.className = 'feat-state mono dim';
      state.textContent = 'display size unavailable';
      return;
    }
    if (wm.override) {
      state.className = 'feat-state mono bad';
      state.textContent = 'override ' + fmtSize(wm.override) + ' \u2014 reset to clear it';
      return;
    }
    state.className = 'feat-state mono good';
    state.textContent = 'override none \u2014 stretch applies';
  }

  function wmReset() {
    var btn = $('wmResetBtn');
    if (btn && btn.disabled) return Promise.resolve(false);
    if (btn) btn.disabled = true;

    var note = $('wmNote');
    if (note) {
      note.hidden = true;
      note.textContent = '';
    }

    overlayOpen('', '', {
      kicker: 'display override',
      title: 'ANALYZING',
      sub: 'wm size reset',
      steps: WM_RESET_STEPS,
      duration: WM_RESET_MS,
      ratio: false,
      note: 'Clearing the wm size override and reading the panel back. Keep this page open.'
    });

    var started = Date.now();

    return run(K.wmResetCmd()).then(function (res) {
      var out = String(res.stdout || '');
      var shellOk = res.errno === 0;
      var parts = wmParts(out);
      var ok = shellOk && !parts.override;
      /* The shell usually answers in well under a second; the overlay still
       * runs the full five so the progress the user asked for is real, not a
       * flash. */
      var wait = Math.max(0, WM_RESET_MS - (Date.now() - started));

      return new Promise(function (resolve) {
        window.setTimeout(function () {
          /* Keep the fresh read even on failure: it is the honest state of the
           * panel, and the note below says what is still holding it. */
          if (out) S.device.wm = out;
          renderStatus();
          renderPreview();
          paintWmCard();
          if (btn) btn.disabled = false;

          if (note) {
            note.hidden = false;
            if (ok) {
              note.textContent = 'WM size override cleared. If a WM Size module or a WM Size app is still installed, remove it \u2014 it will set the override again, and the stretch will not apply while it is set.';
            } else if (!shellOk) {
              note.textContent = 'The shell did not answer. Reopen this page from the root manager and run Reset again.';
            } else {
              note.textContent = 'Reset did not clear the override' +
                (parts.override ? ' (' + fmtSize(parts.override) + ')' : '') +
                '. Remove the WM Size module or the WM Size app that set it, then run Reset again.';
            }
          }

          overlayDone(ok, ok ? '' : (shellOk
            ? 'wm size still reports an override. remove the WM Size module or app and try again.'
            : 'the shell did not answer. reopen the page from the root manager.'), {
            okKicker: 'display override',
            okTitle: 'CLEARED',
            okStep: 'wm size reset',
            okNote: 'The Device card now reads none. Reopen the game and the stretch lines up with the panel.',
            errKicker: 'reset blocked',
            errTitle: 'STILL SET',
            errStep: 'a module or app re-applied it'
          });

          window.setTimeout(function () {
            overlayClose();
            resolve(ok);
          }, ok ? 1000 : 2600);
        }, wait);
      });
    });
  }

  /* --------------------------------------------------------------- preview */

  /* `wm size` reports the natural (portrait) orientation. Returns
   * { short, long } in pixels, or null when the value is unusable. */
  function displaySize() {
    var match = /(\d+)\s*x\s*(\d+)/g;
    var found = null;
    var m;
    var wm = String(S.device.wm || '');
    while ((m = match.exec(wm)) !== null) {
      found = [parseInt(m[1], 10), parseInt(m[2], 10)];
    }
    if (!found || !found[0] || !found[1]) return null;
    return {
      short: Math.min(found[0], found[1]),
      long: Math.max(found[0], found[1])
    };
  }

  function parseRatio(value) {
    var m = /^(\d{1,2})x(\d{1,2})$/.exec(String(value || ''));
    if (!m) return null;
    var num = parseInt(m[1], 10);
    var den = parseInt(m[2], 10);
    if (!(num >= 1 && num <= 32) || !(den >= 1 && den <= 32)) return null;
    return { num: num, den: den };
  }

  /* Mirrors koyri_buffer_hook.cpp stretch_dims() and Boot.maybeActivate():
   * anchor the short side of the window on the display and derive the long
   * side from the ratio. */
  function geometry() {
    var d = displaySize();
    if (!d) return null;
    var portrait = S.orientation === 'portrait';
    var W = portrait ? d.short : d.long;
    var H = portrait ? d.long : d.short;

    var out = {
      portrait: portrait,
      displayW: W,
      displayH: H,
      ratio: S.ratio,
      ratioLabel: S.ratio ? S.ratio.replace('x', ':') : 'off',
      viewW: W,
      viewH: H,
      bufferW: W,
      bufferH: H
    };

    var r = parseRatio(S.ratio);
    if (!r) return out;

    if (!portrait) {
      out.viewH = H;
      out.viewW = Math.round(H * r.num / r.den);
    } else {
      out.viewW = W;
      out.viewH = Math.round(W * r.num / r.den);
    }
    if (out.viewW < 1) out.viewW = 1;
    if (out.viewH < 1) out.viewH = 1;

    /* Same safety ceiling as Boot.java and koyri_buffer_hook.cpp: scale both sides down
     * together so the preview shows the buffer the device will really allocate. */
    if (out.viewW > MAX_BUFFER_SIDE) {
      out.viewH = Math.round(out.viewH * MAX_BUFFER_SIDE / out.viewW);
      out.viewW = MAX_BUFFER_SIDE;
    }
    if (out.viewH > MAX_BUFFER_SIDE) {
      out.viewW = Math.round(out.viewW * MAX_BUFFER_SIDE / out.viewH);
      out.viewH = MAX_BUFFER_SIDE;
    }
    if (out.viewW < 1) out.viewW = 1;
    if (out.viewH < 1) out.viewH = 1;

    out.bufferW = out.viewW;
    out.bufferH = out.viewH;
    return out;
  }

  function renderPreview() {
    var stage = $('prevStage');
    if (!stage) return;

    var g = geometry();
    var screen = $('prevScreen');
    var empty = $('prevEmpty');
    var stats = $('previewStats');
    var who = $('previewWho');
    var note = $('previewNote');
    var buffer = $('prevBuffer');
    var screenTag = $('prevScreenTag');

    if (who) who.textContent = S.pkg || (S.ratio ? S.ratio.replace('x', ':') : 'no target');

    if (!g) {
      if (screen) screen.style.display = 'none';
      if (empty) empty.hidden = false;
      clear(stats);
      if (note) {
        note.textContent = 'Display size unavailable — the shell bridge could not read `wm size`. The module itself does not need it; this is preview only.';
        note.className = 'note warn';
      }
      return;
    }

    if (screen) screen.style.display = '';
    if (empty) empty.hidden = true;

    /* Fit the display frame into the stage budget, then draw the buffer box at
     * its own aspect anchored on the short side: the leftover strips are
     * exactly the area SurfaceFlinger stretches to fill the window.
     *
     * The budget follows the stage's real width. A fixed 300x168 collapsed a
     * square panel (a wm size override left on) to a 168 px thumbnail, which
     * read as a bug instead of the honest shape of the display. */
    var stageW = stage ? Math.max(160, stage.clientWidth - 10) : 300;
    var maxW = Math.min(stageW, g.portrait ? 220 : 420);
    var maxH = g.portrait ? 300 : 250;
    var fit = Math.min(maxW / g.displayW, maxH / g.displayH);
    var screenW = Math.max(40, Math.round(g.displayW * fit));
    var screenH = Math.max(40, Math.round(g.displayH * fit));

    if (screen) {
      screen.style.width = screenW + 'px';
      screen.style.height = screenH + 'px';
    }

    var boxW;
    var boxH;
    if (!g.portrait) {
      boxH = screenH;
      boxW = Math.round(boxH * g.bufferW / g.bufferH);
      if (boxW > screenW) {
        boxW = screenW;
        boxH = Math.round(boxW * g.bufferH / g.bufferW);
      }
    } else {
      boxW = screenW;
      boxH = Math.round(boxW * g.bufferH / g.bufferW);
      if (boxH > screenH) {
        boxH = screenH;
        boxW = Math.round(boxH * g.bufferW / g.bufferH);
      }
    }
    if (buffer) {
      var bw = Math.max(12, boxW);
      var bh = Math.max(12, boxH);
      buffer.style.width = bw + 'px';
      buffer.style.height = bh + 'px';
      /* The game renders into the buffer; SurfaceFlinger stretches that buffer
       * onto the whole display. Scaling by exactly display/buffer reproduces
       * that second step, so the preview shows the final picture. */
      buffer.style.transform = 'translate(-50%, -50%) scale(' +
        (screenW / bw).toFixed(4) + ', ' + (screenH / bh).toFixed(4) + ')';
    }

    if (screenTag) screenTag.textContent = g.displayW + '\u00d7' + g.displayH;

    clear(stats);
    [
      ['display', g.displayW + '\u00d7' + g.displayH],
      ['buffer', S.ratio ? g.bufferW + '\u00d7' + g.bufferH : 'real'],
      ['ratio', g.ratioLabel],
      ['mode', g.portrait ? 'portrait' : 'landscape']
    ].forEach(function (pair) {
      var chip = el('span', 'hstat', pair[0]);
      chip.appendChild(document.createTextNode(' '));
      chip.appendChild(el('b', null, pair[1]));
      stats.appendChild(chip);
    });

    if (note) {
      if (!S.ratio) {
        note.textContent = 'No stretch: the game keeps the real display aspect. Pick a ratio above to see the target shape.';
      } else if (g.portrait) {
        note.textContent = 'Portrait preview. Portrait stretching only runs when the target has koyri.portrait=1; otherwise the module steps out on portrait windows and the game keeps its normal shape.';
      } else {
        var stretched = Math.abs((g.displayW / g.displayH) - (g.bufferW / g.bufferH)) > 0.01;
        note.textContent = stretched
          ? 'The buffer renders at ' + g.ratioLabel + ' and is scaled onto the ' + g.displayW + '\u00d7' + g.displayH + ' window, so the picture widens to fill it.'
          : 'Buffer aspect matches the window: the stretch is a no-op at this ratio on this device.';
      }
      note.className = 'note' + (g.portrait && !extraState().portrait ? ' warn' : '');
    }
  }

  function setPreviewImage(src, label) {
    var img = $('prevImage');
    var text = $('prevImageLabel');
    if (!img) return;
    if (!src) {
      img.hidden = true;
      img.removeAttribute('src');
      if (text) text.textContent = 'no image';
      return;
    }
    img.hidden = false;
    img.src = src;
    if (text) text.textContent = label || 'preview image';
  }

  /* ---------------------------------------------------------------- ratios */

  function renderRatioGrid() {
    var grid = $('ratioGrid');
    if (!grid) return;
    clear(grid);

    RATIOS.forEach(function (opt) {
      var btn = el('button', 'ratio-tile' + (opt.restore ? ' restore' : ''));
      btn.type = 'button';
      btn.setAttribute('data-ratio', opt.v);
      btn.appendChild(el('span', 'rt-name', opt.name));
      btn.appendChild(el('span', 'rt-sub', opt.sub));
      if (opt.v) btn.appendChild(el('span', 'rt-x', opt.v));
      on(btn, 'click', function () {
        S.ratio = opt.v;
        var input = $('ratioInput');
        if (input) input.value = opt.v;
        paintRatios();
        renderPreview();
        updateEditorState();
      });
      grid.appendChild(btn);
    });
    paintRatios();
  }

  function paintRatios() {
    var grid = $('ratioGrid');
    if (!grid) return;
    var tiles = grid.getElementsByTagName('button');
    for (var i = 0; i < tiles.length; i++) {
      var tile = tiles[i];
      var value = tile.getAttribute('data-ratio') || '';
      var active = value === S.ratio;
      tile.className = 'ratio-tile' + (value ? '' : ' restore') + (active ? ' active' : '');
      tile.setAttribute('aria-pressed', active ? 'true' : 'false');
    }
  }

  /* --------------------------------------------------------- target config */

  /* The three per-target switches live in switches.js. Absent (module missing /
   * load order) means "leave the saved values alone" for an edit and "safe
   * defaults" for a new target. */
  function extraState() {
    if (window.KSSwitches && typeof window.KSSwitches.get === 'function') {
      var v = window.KSSwitches.get();
      if (v) {
        return {
          touch: v.touch !== false,
          portrait: v.portrait === true,
          cutout: v.cutout === true
        };
      }
    }
    return { touch: true, portrait: false, cutout: false };
  }

  function loadExtras(name, cfg) {
    if (window.KSSwitches && typeof window.KSSwitches.load === 'function') {
      window.KSSwitches.load(name, cfg || null);
    }
  }

  function cfgOf(name) {
    var t = S.targets[name];
    if (!t) return null;
    return {
      ratio: t.ratio,
      touch: t.touch,
      portrait: t.portrait,
      cutout: t.cutout
    };
  }

  function updateEditorState() {
    var state = $('editorState');
    if (!state) return;
    var name = String(($('pkgInput') || {}).value || '').trim();
    if (!name) {
      state.textContent = 'NEW';
      return;
    }
    state.textContent = S.targets[name] ? 'EDIT' : 'NEW';
  }

  /* Called whenever the package in the editor changes (typing, detect, browse,
   * tapping a target row, opening a target for edit). */
  function syncEditor() {
    var name = String(($('pkgInput') || {}).value || '').trim();
    S.pkg = name;
    if (K.validPkg(name) && S.targets[name]) {
      S.ratio = S.targets[name].ratio;
      var input = $('ratioInput');
      if (input) input.value = S.ratio;
      paintRatios();
      loadExtras(name, cfgOf(name));
    } else {
      loadExtras(name, null);
    }
    updateEditorState();
    renderPreview();
  }

  /* --------------------------------------------------------------- targets */

  function refreshTargets() {
    return run(K.listCmd()).then(function (res) {
      if (res.errno !== 0) return;
      var next = {};
      String(res.stdout || '').split('\n').forEach(function (line) {
        var parts = line.trim().split(/\s+/);
        if (parts.length < 2) return;
        var name = parts[0];
        if (!K.validPkg(name) || !K.validRatio(parts[1])) return;
        next[name] = {
          ratio: parts[1],
          touch: parts[2] !== '0',
          portrait: parts[3] === '1',
          cutout: parts[4] === '1'
        };
      });
      S.targets = next;
      renderTargets();
      syncEditor();
    });
  }

  function ratioOptionsFor(current) {
    var out = RATIOS.slice(0);
    var known = out.some(function (r) { return r.v === current; });
    if (current && !known) out.unshift({ v: current, name: current.replace('x', ':'), sub: 'custom' });
    return out;
  }

  function renderTargets() {
    var list = $('targetList');
    var count = $('targetsCount');
    if (!list) return;
    clear(list);

    var names = Object.keys(S.targets).sort();
    if (count) count.textContent = String(names.length);

    if (!names.length) {
      var empty = el('div', 'target-empty',
        'No targets yet. Type a package (or tap Apps), pick a ratio and hit INJECT. The module only loads inside the apps listed here.');
      list.appendChild(empty);
      return;
    }

    names.forEach(function (name) {
      var t = S.targets[name];
      var row = el('div', 'target-row' + (name === S.pkg ? ' is-active' : ''));

      var pkg = el('button', 'target-pkg', name);
      pkg.type = 'button';
      on(pkg, 'click', function () {
        var input = $('pkgInput');
        if (input) input.value = name;
        S.ratio = t.ratio;
        var custom = $('ratioInput');
        if (custom) custom.value = t.ratio;
        syncEditor();
        renderTargets();
        var editor = $('pkgInput');
        if (editor && editor.scrollIntoView) editor.scrollIntoView({ block: 'center', behavior: 'smooth' });
      });
      row.appendChild(pkg);

      var meta = el('div', 'target-meta mono',
        t.ratio.replace('x', ':') +
        '  \u00b7  touch ' + (t.touch ? 'on' : 'off') +
        '  \u00b7  portrait ' + (t.portrait ? 'on' : 'off') +
        '  \u00b7  cutout ' + (t.cutout ? 'on' : 'off'));
      row.appendChild(meta);

      var ctl = el('div', 'target-ctl');
      var sel = el('select', 'target-sel');
      sel.setAttribute('aria-label', 'ratio for ' + name);
      ratioOptionsFor(t.ratio).forEach(function (opt) {
        var o = el('option', null, opt.name + (opt.v ? '  (' + opt.v + ')' : ''));
        o.value = opt.v;
        if (opt.v === t.ratio) o.selected = true;
        sel.appendChild(o);
      });
      on(sel, 'change', function () {
        quickSave(name, sel.value);
      });
      ctl.appendChild(sel);

      var del = el('button', 'target-del', '\u00d7');
      del.type = 'button';
      del.setAttribute('aria-label', 'remove ' + name);
      on(del, 'click', function () {
        removeTarget(name);
      });
      ctl.appendChild(del);
      row.appendChild(ctl);
      list.appendChild(row);
    });
  }

  /* Inline ratio change from a target row: keeps the saved switches. */
  function quickSave(name, ratio) {
    var current = S.targets[name] || { touch: true, portrait: false, cutout: false };
    if (!ratio) {
      removeTarget(name);
      return;
    }
    var cmd = K.saveTargetCmd(name, {
      ratio: ratio,
      touch: current.touch,
      portrait: current.portrait,
      cutout: current.cutout
    });
    if (!cmd) {
      toast('invalid ratio');
      return;
    }
    run(cmd).then(function (res) {
      if (res.errno === 0) {
        toast(name + ' \u2192 ' + ratio.replace('x', ':'));
        refreshTargets();
      } else {
        toast('save failed');
      }
    });
  }

  function removeTarget(name) {
    var cmd = K.removeTargetCmd(name);
    if (!cmd) return;
    run(cmd).then(function (res) {
      if (res.errno === 0) {
        toast('removed ' + name);
        if (S.pkg === name) {
          var input = $('pkgInput');
          if (input) input.value = '';
        }
        refreshTargets();
        refreshStatus();
      } else {
        toast('remove failed');
      }
    });
  }

  /* ------------------------------------------------------- inject sequence */

  var inject = { timer: null, started: 0, done: false, steps: INJECT_STEPS, duration: 0 };

  function overlayProgress(pct) {
    var fill = $('injectBarFill');
    var bar = $('injectBar');
    var value = Math.max(0, Math.min(100, Math.round(pct)));
    if (fill) fill.style.width = value + '%';
    if (bar) bar.setAttribute('aria-valuenow', String(value));
  }

  /* `opts` lets the same overlay run a second job: a fixed-duration run with its
   * own copy and steps (the wm size reset), instead of the write flow's tick
   * driven progress. Everything it does not name keeps the injection wording. */
  function overlayOpen(pkg, ratioText, opts) {
    opts = opts || {};
    var overlay = $('injectOverlay');
    var panel = $('injectPanel');
    if (!overlay) return;

    inject.done = false;
    inject.started = Date.now();
    inject.steps = opts.steps || INJECT_STEPS;
    inject.duration = opts.duration || 0;
    overlay.hidden = false;
    document.documentElement.classList.add('injecting');
    document.body.classList.add('injecting');
    if (panel) panel.className = 'inject-panel';
    var kicker = $('injectKicker');
    if (kicker) kicker.textContent = opts.kicker || 'target injection';
    var title = $('injectTitle');
    if (title) title.textContent = opts.title || 'ANALYZING';
    var sub = $('injectSub');
    if (sub) sub.textContent = opts.sub || pkg;
    var step = $('injectStep');
    if (step) step.textContent = inject.steps[0];
    var ratioRow = $('injectRatioRowLabel');
    if (ratioRow && ratioRow.parentNode) ratioRow.parentNode.hidden = opts.ratio === false;
    var ratio = $('injectRatio');
    if (ratio) ratio.textContent = ratioText || '\u2014';
    var note = $('injectNote');
    if (note) note.textContent = opts.note ||
      'Writing the target and force-stopping the game. Keep this page open.';
    overlayProgress(0);
    if (panel && panel.focus) {
      try { panel.focus(); } catch (e) { /* cosmetic */ }
    }

    var tick = 0;
    var count = $('injectCountdown');
    if (inject.timer) window.clearInterval(inject.timer);
    inject.timer = window.setInterval(function () {
      tick += 1;
      var elapsed = Date.now() - inject.started;
      var pct = inject.duration
        ? Math.min(96, 4 + (92 * elapsed) / inject.duration)
        : Math.min(90, 8 + tick * 6);
      overlayProgress(pct);
      var idx = Math.min(inject.steps.length - 1,
        Math.floor(pct / (100 / inject.steps.length)));
      var stepNode = $('injectStep');
      if (stepNode) stepNode.textContent = inject.steps[idx];
      if (count) count.textContent = Math.max(1, Math.round(elapsed / 1000)) + 's';
    }, 160);
  }

  function overlayDone(ok, message, texts) {
    texts = texts || {};
    var panel = $('injectPanel');
    var title = $('injectTitle');
    var note = $('injectNote');
    var step = $('injectStep');
    var kicker = $('injectKicker');
    inject.done = true;
    if (inject.timer) {
      window.clearInterval(inject.timer);
      inject.timer = null;
    }
    overlayProgress(100);
    if (panel) panel.className = 'inject-panel ' + (ok ? 'ok' : 'err');
    if (kicker) kicker.textContent = ok
      ? (texts.okKicker || 'target written')
      : (texts.errKicker || 'injection failed');
    if (title) title.textContent = ok
      ? (texts.okTitle || 'INJECTED')
      : (texts.errTitle || 'FAILED');
    if (step) step.textContent = ok
      ? (texts.okStep || 'reopen the game to apply')
      : (texts.errStep || 'see the note below');
    var count = $('injectCountdown');
    if (count) count.textContent = ok ? 'done' : 'error';
    if (note) {
      note.textContent = ok
        ? (texts.okNote || 'Saved. The module finishes the job the next time the game process starts — reopen the app.')
        : String(message || 'The shell command failed.').slice(0, 220);
    }
  }

  function overlayClose() {
    var overlay = $('injectOverlay');
    if (inject.timer) {
      window.clearInterval(inject.timer);
      inject.timer = null;
    }
    inject.duration = 0;
    inject.steps = INJECT_STEPS;
    if (overlay) overlay.hidden = true;
    document.documentElement.classList.remove('injecting');
    document.body.classList.remove('injecting');
  }

  /* Writes one target (ratio + switches) and force-stops the package, all
   * inside a single shell round-trip. The overlay is cosmetic: it can never
   * outlive the promise. */
  function injectTarget(name, cfg) {
    var cmd = K.saveTargetCmd(name, cfg);
    if (!cmd) {
      toast('invalid package or ratio');
      return Promise.resolve(false);
    }
    var stop = K.forceStopCmd(name);
    var full = stop ? cmd + '\n' + stop : cmd;

    var ratioText = cfg.ratio ? cfg.ratio.replace('x', ':') : 'default';
    overlayOpen(name, ratioText);

    return run(full).then(function (res) {
      var ok = res.errno === 0;
      var message = ok ? '' : (res.stderr || res.stdout || 'command failed');
      var elapsed = Date.now() - inject.started;
      var wait = Math.max(0, 750 - elapsed);
      return new Promise(function (resolve) {
        window.setTimeout(function () {
          overlayDone(ok, message);
          window.setTimeout(function () {
            overlayClose();
            resolve(ok);
          }, ok ? 850 : 2400);
        }, wait);
      });
    }).then(function (ok) {
      if (ok) {
        refreshTargets();
        refreshStatus();
        refreshLog();
      }
      return ok;
    });
  }

  function onSave() {
    var name = String(($('pkgInput') || {}).value || '').trim();
    if (!K.validPkg(name)) {
      toast('enter a valid package name');
      return;
    }
    if (!S.ratio) {
      if (S.targets[name]) removeTarget(name);
      else toast('pick a ratio first');
      return;
    }
    var extra = extraState();
    injectTarget(name, {
      ratio: S.ratio,
      touch: extra.touch,
      portrait: extra.portrait,
      cutout: extra.cutout
    });
  }

  /* ------------------------------------------------------------ export/import */

  function exportTargets() {
    var names = Object.keys(S.targets).sort();
    if (!names.length) {
      toast('nothing to export');
      return;
    }
    var payload = {
      module: 'koyri_stretch',
      version: 1,
      created: Math.floor(Date.now() / 1000),
      targets: names.map(function (name) {
        var t = S.targets[name];
        return {
          package: name,
          ratio: t.ratio,
          touch: t.touch,
          portrait: t.portrait,
          cutout: t.cutout
        };
      })
    };
    var json = JSON.stringify(payload, null, 2);
    /* JSON produced above only ever contains validated package names, ratios
     * and numbers — no single quotes — so a quoted heredoc-free write is safe. */
    if (json.indexOf("'") !== -1) {
      toast('export aborted: unexpected quote');
      return;
    }
    var path = '/sdcard/Download/koyri-stretch-backup.json';
    /* Atomic like every other write in core.js: temp file, chmod, mv. A killed
     * page cannot leave a truncated backup behind. */
    var cmd = [
      'P=' + path,
      'T="$P.tmp.$$"',
      'mkdir -p /sdcard/Download 2>/dev/null',
      "printf '%s\\n' '" + json + "' > \"$T\" 2>/dev/null || { rm -f \"$T\"; echo 'write failed' >&2; exit 1; }",
      'chmod 644 \"$T\" 2>/dev/null',
      'mv -f \"$T\" \"$P\" 2>/dev/null || { rm -f \"$T\"; echo \"rename failed\" >&2; exit 1; }',
      'echo \"$P\"'
    ].join('\n');

    run(cmd).then(function (res) {
      if (res.errno === 0) toast('exported ' + names.length + ' target(s) to Download');
      else toast('export failed');
    });
  }

  /* The path comes from the input above the button, not window.prompt: an
   * Android WebView returns null from onJsPrompt unless the host overrides it,
   * so a prompt-based import silently did nothing on a phone. */
  function importTargets() {
    var field = $('importPath');
    var path = field && typeof field.value === 'string' ? field.value.trim() : '';
    if (!path) {
      toast('enter a backup path');
      return;
    }

    /* One shell word: single quotes with the standard '\'' escape, so a path
     * with spaces works and an embedded quote can never start a command. */
    var quoted = "'" + path.replace(/'/g, "'\\''") + "'";
    run('cat ' + quoted + ' 2>/dev/null').then(function (res) {
      if (res.errno !== 0 || !res.stdout) {
        toast('cannot read ' + path);
        return;
      }
      var data;
      try {
        data = JSON.parse(res.stdout);
      } catch (e) {
        toast('not valid JSON');
        return;
      }
      var list = (data && data.targets) || [];
      if (!list.length) {
        toast('no targets in that file');
        return;
      }
      var commands = [];
      var accepted = 0;
      list.forEach(function (item) {
        if (!item) return;
        var name = String(item.package || '');
        var ratio = String(item.ratio || '');
        if (!K.validPkg(name) || !K.validRatio(ratio)) return;
        var cmd = K.saveTargetCmd(name, {
          ratio: ratio,
          touch: item.touch !== false,
          portrait: item.portrait === true,
          cutout: item.cutout === true
        });
        if (!cmd) return;
        commands.push(cmd);
        accepted += 1;
      });
      if (!commands.length) {
        toast('no valid targets in that file');
        return;
      }
      run(commands.join('\n')).then(function (write) {
        if (write.errno === 0) {
          toast('imported ' + accepted + ' target(s)');
          refreshTargets();
          refreshStatus();
        } else {
          toast('import failed');
        }
      });
    });
  }

  /* --------------------------------------------------------------- packages */

  function detectForeground() {
    run(K.detectCmd()).then(function (res) {
      if (res.errno !== 0) return;
      var matches = String(res.stdout || '').match(/[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+/g) || [];
      var candidates = matches.filter(function (name) {
        return K.validPkg(name) && !/build$/.test(name);
      });
      var preferred = candidates.filter(function (name) {
        return name.indexOf('com.android.') !== 0 && name !== 'android';
      });
      var pick = preferred[0] || candidates[0] || '';
      if (!pick) {
        toast('no foreground app detected');
        return;
      }
      var input = $('pkgInput');
      if (input) input.value = pick;
      syncEditor();
      renderTargets();
      toast('detected ' + pick);
    });
  }

  function openSheet() {
    var sheet = $('pkgSheet');
    if (!sheet) return;
    sheet.hidden = false;
    if (S.packages) {
      renderPackages();
      return;
    }
    var meta = $('pkgMeta');
    if (meta) meta.textContent = 'loading…';
    run(K.packagesCmd()).then(function (res) {
      var list = String(res.stdout || '').split('\n').map(function (line) {
        return line.trim();
      }).filter(function (line) {
        return K.validPkg(line);
      });
      S.packages = list;
      renderPackages();
    });
  }

  function closeSheet() {
    var sheet = $('pkgSheet');
    if (sheet) sheet.hidden = true;
  }

  function renderPackages() {
    var list = $('pkgList');
    var meta = $('pkgMeta');
    if (!list) return;
    clear(list);

    var query = String(($('pkgSearch') || {}).value || '').trim().toLowerCase();
    var all = S.packages || [];
    var shown = query ? all.filter(function (name) {
      return name.toLowerCase().indexOf(query) !== -1;
    }) : all;

    if (meta) {
      meta.textContent = shown.length + ' / ' + all.length + ' packages' +
        (query ? '  ·  filter "' + query + '"' : '');
    }

    if (!shown.length) {
      list.appendChild(el('div', 'pkg-empty', 'No package matches that search.'));
      return;
    }

    var limit = 300;
    shown.slice(0, limit).forEach(function (name) {
      var row = el('button', 'app-row');
      row.type = 'button';
      row.appendChild(el('span', 'pp', name));
      row.appendChild(el('span', 'pa', S.targets[name] ? 'targeted' : ''));
      on(row, 'click', function () {
        var input = $('pkgInput');
        if (input) input.value = name;
        syncEditor();
        renderTargets();
        closeSheet();
      });
      list.appendChild(row);
    });

    if (shown.length > limit) {
      list.appendChild(el('div', 'pkg-empty',
        'Showing the first ' + limit + '. Type in the search box to narrow it down.'));
    }
  }

  /* ------------------------------------------------------------------- log */

  function refreshLog() {
    return run(K.logCmd()).then(function (res) {
      var node = $('log');
      if (!node) return;
      clear(node);
      var text = String(res.stdout || '').replace(/\s+$/, '');
      if (!text) {
        node.appendChild(el('div', 'log-empty', 'no module log yet — inject a target and open the game once'));
        return;
      }
      var lines = text.split('\n').slice(-400);
      lines.forEach(function (line) {
        node.appendChild(el('div', 'log-line', line));
      });
      node.scrollTop = node.scrollHeight;
    });
  }

  /* Touch probe. Shows the activation line (origin + scale), the first taps of the session and
   * the first taps in the top band. If tapping the top of the screen produces no line at all,
   * the touch never reached the app — SystemUI owns that band, which is the case edge-to-edge
   * fixes. If it produces a mapped point that is negative or outside the buffer, it is the
   * remap, and the clamp handles it. */
  function diagnoseTouch() {
    return run(K.diagnoseCmd()).then(function (res) {
      var node = $('log');
      if (!node) return;
      clear(node);
      var text = String(res.stdout || '').replace(/\s+$/, '');
      if (!text) {
        node.appendChild(el('div', 'log-empty',
          'no touch probe lines — open the game, tap the top of the screen, then run this again'));
        return;
      }
      text.split('\n').slice(-400).forEach(function (line) {
        node.appendChild(el('div', 'log-line', line));
      });
      node.scrollTop = node.scrollHeight;
      toast('touch probe loaded');
    });
  }

  /* ----------------------------------------------------------------- wiring */

  function wire() {
    on($('refreshBtn'), 'click', function () {
      refreshStatus();
      refreshTargets();
      toast('refreshed');
    });
    on($('retryBtn'), 'click', function () {
      boot();
    });
    on($('wmResetBtn'), 'click', function () {
      wmReset();
    });
    on($('logBtn'), 'click', function () {
      refreshLog();
    });
    on($('diagBtn'), 'click', function () {
      diagnoseTouch();
    });
    on($('detectBtn'), 'click', detectForeground);
    on($('browseBtn'), 'click', openSheet);
    on($('sheetClose'), 'click', closeSheet);
    on($('pkgSheet'), 'click', function (ev) {
      if (ev.target === $('pkgSheet')) closeSheet();
    });
    on($('pkgSearch'), 'input', renderPackages);
    on($('saveBtn'), 'click', onSave);
    on($('clearBtn'), 'click', function () {
      var input = $('pkgInput');
      if (input) input.value = '';
      S.ratio = '16x9';
      var custom = $('ratioInput');
      if (custom) custom.value = '';
      syncEditor();
      // syncEditor() only repaints the grid when it loads a saved target, so a
      // cleared editor used to keep the previous tile marked active while
      // S.ratio already read 16x9 -- Save would then write a ratio the grid did
      // not show.
      paintRatios();
      renderTargets();
    });
    on($('exportBtn'), 'click', exportTargets);
    on($('importBtn'), 'click', importTargets);

    on($('pkgInput'), 'input', function () {
      syncEditor();
      renderTargets();
    });

    /* Custom ratio field: any NxM the module accepts. */
    var applyCustom = function () {
      var input = $('ratioInput');
      if (!input) return;
      var value = String(input.value || '').trim().toLowerCase().replace(/\s+/g, '');
      if (!value) return;
      if (!K.validRatio(value)) {
        toast('ratio must be NxM, 1..32 per side');
        return;
      }
      S.ratio = value;
      paintRatios();
      renderPreview();
      updateEditorState();
      toast('ratio ' + value.replace('x', ':'));
    };
    on($('ratioApplyBtn'), 'click', applyCustom);
    on($('ratioInput'), 'keydown', function (ev) {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        applyCustom();
      }
    });

    on($('prevLandscapeBtn'), 'click', function () {
      S.orientation = 'landscape';
      paintOrientation();
    });
    on($('prevPortraitBtn'), 'click', function () {
      S.orientation = 'portrait';
      paintOrientation();
    });

    on($('prevTestBtn'), 'click', function () {
      setPreviewImage(window.KSDefaultPreview || '', 'default preview');
      toast('preview reset');
    });
    on($('prevImageBtn'), 'click', function () {
      var input = $('prevImageInput');
      if (input) input.click();
    });
    on($('prevImageInput'), 'change', function (ev) {
      var file = ev && ev.target && ev.target.files && ev.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        /* data: URLs only — the page CSP allows img-src 'self' data:, not blob:. */
        setPreviewImage(String(reader.result || ''), file.name || 'custom image');
      };
      reader.readAsDataURL(file);
    });

    on($('injectOverlay'), 'click', function () {
      if (inject.done) overlayClose();
    });
    /* The preview frame is sized from the stage's real width, so a rotation or
     * a desktop resize has to repaint it. */
    on(window, 'resize', function () {
      renderPreview();
    });
    on(document, 'keydown', function (ev) {
      if (ev.key === 'Escape') {
        closeSheet();
        if (!($('injectOverlay') || {}).hidden) overlayClose();
      }
    });
  }

  function paintOrientation() {
    var portrait = S.orientation === 'portrait';
    var land = $('prevLandscapeBtn');
    var port = $('prevPortraitBtn');
    if (land) {
      land.classList.toggle('active', !portrait);
      land.setAttribute('aria-pressed', portrait ? 'false' : 'true');
    }
    if (port) {
      port.classList.toggle('active', portrait);
      port.setAttribute('aria-pressed', portrait ? 'true' : 'false');
    }
    renderPreview();
  }

  /* ------------------------------------------------------------------- boot */

  function boot() {
    S.bridge = bridgePresent();
    if (!S.bridge) {
      setStatus('err', 'NO BRIDGE');
      showBanner('open this page from the module WebUI in your root manager',
        'KernelSU, KernelSU-Next, APatch, SukiSU and MMRL WebUI X expose window.ksu / window.mmrl. A plain browser tab has no shell.');
      var grid = $('statusGrid');
      if (grid) {
        clear(grid);
        var box = el('div', 'kv-row wide');
        box.appendChild(el('span', 'kv-k', 'bridge'));
        box.appendChild(el('span', 'kv-v bad', 'not available — nothing can be read or written from here'));
        grid.appendChild(box);
      }
      renderPreview();
      return;
    }
    hideBanner();
    setStatus('warn', 'LINKING');
    refreshStatus().then(function () {
      paintStatusPill();
      return refreshTargets();
    }).then(function () {
      refreshLog();
    });
  }

  function init() {
    setPreviewImage(window.KSDefaultPreview || '', 'default preview');
    renderRatioGrid();
    renderTargets();
    renderPreview();
    wire();
    paintOrientation();
    boot();
  }

  /* app.js loads before switches.js, so the switch chips ask this hook to
   * re-sync once their own state exists. */
  window.KSApp = {
    syncEditor: syncEditor,
    refreshPreview: renderPreview,
    refreshTargets: refreshTargets,
    toast: toast
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
