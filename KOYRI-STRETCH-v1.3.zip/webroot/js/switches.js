/* KOYRI STRETCH — per-target switches (editor state only).
 *
 * The Stretch pane owns the aspect (koyri.stretch=<NxM>) and these three
 * switches ride in the same INJECT:
 *
 *   koyri.touch=0            leave raw input coordinates alone
 *   koyri.portrait=1         stretch portrait windows too
 *   koyri.cutout=1           flatten DisplayCutout safe insets
 *
 * This file owns no shell and no ratio: it is pure editor state. app.js reads
 * it through window.KSSwitches.get() when INJECT runs, and pushes the saved
 * values back with window.KSSwitches.load(pkg, cfg) whenever the editor
 * switches package. One writer, one round-trip, no monkey-patching of core.js.
 *
 * Absence of a sidecar file always means the default:
 *
 *   <pkg>                  koyri.stretch=16x9
 *   <pkg>.koyri-touch      koyri.touch=0       (absent = remap on)
 *   <pkg>.koyri-portrait   koyri.portrait=1    (absent = off)
 *   <pkg>.koyri-cutout     koyri.cutout=1      (absent = off)
 */
(function () {
  'use strict';

  var SWITCHES = [
    {
      key: 'touch', id: 'swTouch', title: 'Touch remap', on: true,
      hint: 'off = the game gets untouched input coordinates'
    },
    {
      key: 'portrait', id: 'swPortrait', title: 'Portrait stretch', on: false,
      hint: 'on = stretch portrait windows too'
    },
    {
      key: 'cutout', id: 'swCutout', title: 'Cutout flatten', on: false,
      hint: 'on = zero the DisplayCutout safe insets'
    }
  ];

  var state = { pkg: '', touch: true, portrait: false, cutout: false };
  var listeners = [];
  var chips = {};

  function $(id) {
    return document.getElementById(id);
  }

  function emit() {
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](state); } catch (e) { /* a listener must never break the pane */ }
    }
  }

  /* ---------------------------------------------------------------- switches */

  function buildSwitches() {
    SWITCHES.forEach(function (def) {
      var node = $(def.id);
      if (!node) return;
      chips[def.key] = node;
      node.setAttribute('role', 'switch');
      node.addEventListener('click', function () {
        state[def.key] = !state[def.key];
        paint();
        emit();
      });
    });
  }

  /* ------------------------------------------------------------------- paint */

  function paint() {
    SWITCHES.forEach(function (def) {
      var node = chips[def.key];
      if (!node) return;
      var on = state[def.key] === true;
      node.classList.toggle('on', on);
      node.setAttribute('aria-checked', on ? 'true' : 'false');
      node.textContent = def.title + (on ? ': ON' : ': OFF');
    });
  }

  /* --------------------------------------------------------------- public API */

  /* `cfg` is the object app.js keeps for a saved target, or null for a new one.
   * A cfg that came from disk is authoritative: the editor never shows a stale
   * switch state while the package in the field belongs to someone else. */
  function load(pkg, cfg) {
    state.pkg = String(pkg || '');
    if (cfg) {
      state.touch = cfg.touch !== false;
      state.portrait = cfg.portrait === true;
      state.cutout = cfg.cutout === true;
    } else {
      state.touch = true;
      state.portrait = false;
      state.cutout = false;
    }
    paint();
    emit();
  }

  function get() {
    return {
      touch: state.touch,
      portrait: state.portrait,
      cutout: state.cutout
    };
  }

  function onChange(fn) {
    if (typeof fn === 'function') listeners.push(fn);
  }

  window.KSSwitches = {
    load: load,
    get: get,
    onChange: onChange,
    state: state
  };

  buildSwitches();
  paint();

  /* app.js loaded before this file; ask it to re-sync the editor so a package
   * typed before this pane existed still resolves to its saved values. */
  if (window.KSApp && typeof window.KSApp.syncEditor === 'function') {
    window.KSApp.syncEditor();
  }
  if (window.KSApp && typeof window.KSApp.refreshPreview === 'function') {
    window.KSApp.refreshPreview();
  }
})();
