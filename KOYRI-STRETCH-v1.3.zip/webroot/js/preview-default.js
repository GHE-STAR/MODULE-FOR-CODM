/* KOYRI STRETCH default preview image (bundled asset; loaded as a plain <img>
   source, so no data URL is parsed at startup and the CSP stays strict). */
window.KSDefaultPreview = 'assets/preview-default.jpg';
