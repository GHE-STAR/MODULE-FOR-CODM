#!/system/bin/sh
# KOYRI STRETCH - install screen.
# Standalone Zygisk module: per-game aspect stretch.
# No LSPosed, no wm size, no wm density, no system settings.

SKIPUNZIP=0

MODID=koyri_stretch
CFG=/data/adb/koyri_stretch
LIVE=/data/adb/modules/$MODID

VER="$(sed -n 's/^version=//p' "$MODPATH/module.prop" 2>/dev/null | head -n 1)"
[ -n "$VER" ] || VER="v1.3"

# The channel opened once the flash is done. One value, one place: module.prop
# carries telegram=..., so a re-brand never means hunting through the installer.
CHANNEL_URL="$(sed -n 's/^telegram=//p' "$MODPATH/module.prop" 2>/dev/null | head -n 1 | tr -d '\r')"

OLD=""
if [ -f "$LIVE/module.prop" ]; then
  OLD="$(sed -n 's/^version=//p' "$LIVE/module.prop" 2>/dev/null | head -n 1)"
fi

T0="$(date +%s 2>/dev/null)" || T0=0

CAN_CLEAR=0
if command -v clear >/dev/null 2>&1; then
  if [ "$MMRL" = "true" ] ||
     { [ "$KSU" = "true" ] && [ "${KSU_VER_CODE:-0}" -ge 11998 ]; } ||
     { [ "$KSU_NEXT" = "true" ] && [ "${KSU_VER_CODE:-0}" -ge 12144 ]; } ||
     { [ "$APATCH" = "true" ] && [ "${APATCH_VER_CODE:-0}" -ge 11022 ]; }; then
    CAN_CLEAR=1
  fi
fi

pause() { sleep "$1" 2>/dev/null; }

banner() {
  ui_print " "
  ui_print "  ┌──────────────────────────────┐"
  ui_print "  │   K O Y R I   S T R E T C H  │"
  ui_print "  │   per-game aspect stretch    │"
  ui_print "  └──────────────────────────────┘"
  ui_print "     wide frame · quiet GPU · $VER"
  ui_print " "
}

step() { ui_print "  [$1/6] $2"; pause 0.25; }
good() { ui_print "        ✓ $*"; pause 0.12; }
note() { ui_print "        ! $*"; pause 0.12; }

banner

# ---------------------------------------------------------------- 1/6 device
step 1 "Reading your device"
MODEL="$(getprop ro.product.model)"
ANDROID="$(getprop ro.build.version.release)"
SDK="$(getprop ro.build.version.sdk)"
if [ -z "$ARCH" ]; then
  case "$(getprop ro.product.cpu.abi)" in
    arm64*) ARCH=arm64 ;;
    armeabi*) ARCH=arm ;;
  esac
fi
case "$ARCH" in
  arm64) ABI=arm64-v8a ;;
  arm)   ABI=armeabi-v7a ;;
  *)     abort "Unsupported CPU '$ARCH'. This module ships ARM libraries only (arm64-v8a + armeabi-v7a) - real phones. x86 images (emulators, Chromebooks, Android-x86) cannot run it." ;;
esac
good "Model    : ${MODEL:-unknown}"
good "Android  : ${ANDROID:-?} (API ${SDK:-?})"
good "CPU      : $ABI"
[ -n "$OLD" ] && [ "$OLD" != "$VER" ] && note "Upgrade  : $OLD -> $VER"

# ---------------------------------------------------------------- 2/6 root
step 2 "Checking root"
if [ "$KSU_NEXT" = "true" ]; then ROOT="KernelSU Next (${KSU_VER_CODE:-?})"
elif [ "$KSU" = "true" ] && [ -d /data/adb/suki ]; then ROOT="SukiSU (${KSU_VER_CODE:-?})"
elif [ "$KSU" = "true" ]; then ROOT="KernelSU (${KSU_VER_CODE:-?})"
elif [ "$APATCH" = "true" ]; then ROOT="APatch (${APATCH_VER_CODE:-?})"
elif [ -n "$MAGISK_VER_CODE" ]; then ROOT="Magisk ($MAGISK_VER_CODE)"
else ROOT="unknown"; fi
if [ "$MMRL" = "true" ]; then ROOT="$ROOT + MMRL"; fi
if [ "$ROOT" != "unknown" ]; then good "$ROOT"; else note "Root manager not recognised"; fi

# ---------------------------------------------------------------- 3/6 zygisk
step 3 "Checking Zygisk"
# Every Zygisk provider id known in the wild; official ZygiskNext is "zygisksu",
# older builds "zygisk_next"/"zygisknext", ReZygisk "rezygisk".
ZY=""
for d in zygisksu zygisk_next zygisknext neozygisk rezygisk; do
  if [ -d "/data/adb/modules/$d" ]; then ZY="$d"; break; fi
done
if [ -n "$ZY" ]; then
  if [ -e "/data/adb/modules/$ZY/disable" ]; then
    note "$ZY is installed but disabled - enable it before rebooting"
  else
    good "Zygisk provider: $ZY"
  fi
elif [ -n "$MAGISK_VER_CODE" ]; then
  good "Magisk built-in Zygisk (turn it on in settings)"
else
  note "No Zygisk provider found - the module needs one to load:"
  note "install Zygisk Next (zygisksu) or ReZygisk, then reboot"
fi

# ---------------------------------------------------------------- 4/6 engine
step 4 "Checking the stretch engine"
LIBS_OK=0
for a in arm64-v8a armeabi-v7a; do
  if [ -s "$MODPATH/zygisk/$a.so" ]; then
    if grep -q "koyri.stretch" "$MODPATH/zygisk/$a.so" 2>/dev/null; then
      if grep -q "koyri.portrait=" "$MODPATH/zygisk/$a.so" 2>/dev/null; then
        good "$a.so  $(du -k "$MODPATH/zygisk/$a.so" | cut -f1) KB  marker ok"
      else
        # A library older than the shipped sources cannot honour the WebUI
        # switches (portrait / cutout).
        abort "zygisk/$a.so is an old build (portrait marker missing). Re-download the zip or rebuild from native/."
      fi
      LIBS_OK=$((LIBS_OK + 1))
    else
      abort "zygisk/$a.so is not the stretch payload (marker missing). Re-download the zip."
    fi
  elif [ "$a" = "$ABI" ]; then
    abort "zygisk/$a.so is missing: the module cannot run on this device."
  else
    note "$a.so missing (skipped)"
  fi
done

# ---------------------------------------------------------------- 5/6 panel
step 5 "Preparing WebUI and CLI"
# Drop stale files from older builds that shipped a local control page. The
# current module has no boot service and no helper binaries.
rm -rf "$MODPATH/bin" "$MODPATH/web" 2>/dev/null
rm -f "$MODPATH"/service.* "$MODPATH"/web?.* 2>/dev/null
rm -f /data/local/tmp/koyri_stretch* 2>/dev/null
set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod 0755 "$MODPATH"/*.sh 2>/dev/null
[ -f "$MODPATH/webroot/index.html" ] || abort "webroot/index.html is missing."
[ -f "$MODPATH/webroot/js/switches.js" ] || abort "webroot/js/switches.js is missing (the Stretch pane cannot paint its switches)."
case "$ROOT" in
  Magisk*)
    if [ "$MMRL" = "true" ]; then
      good "WebUI  : ready (MMRL WebUI X)"
    else
      note "Magisk has no built-in WebUI - manage from MMRL WebUI X,"
      note "or the terminal:  sh /data/adb/modules/koyri_stretch/stretch.sh add <pkg> 16x9"
    fi
    ;;
  *) good "WebUI  : ready" ;;
esac
if [ -x "$MODPATH/stretch.sh" ]; then good "CLI    : stretch.sh"; else note "stretch.sh not executable"; fi
if [ -f "$MODPATH/check.sh" ]; then good "Check  : check.sh"; fi
if [ -f "$MODPATH/koyri.avif" ]; then
  # Newer managers draw the module banner from module.prop. Older packs shipped
  # the image but no key, which is why the banner row stayed empty - add it here
  # so an upgrade can never regress that again.
  if ! grep -q '^banner=' "$MODPATH/module.prop" 2>/dev/null; then
    printf 'banner=koyri.avif\n' >> "$MODPATH/module.prop"
    note "banner key was missing - added (shows after the next manager refresh)"
  fi
  good "Banner : koyri.avif"
else
  note "koyri.avif missing - no module banner"
fi

# ---------------------------------------------------------------- 6/6 targets
step 6 "Reading saved targets"
mkdir -p "$CFG" 2>/dev/null
chmod 0755 "$CFG" 2>/dev/null
[ -d "$CFG" ] || abort "Cannot create $CFG (is /data/adb writable?)"
KEPT="$(grep -l '^koyri[.]stretch=' "$CFG"/* 2>/dev/null | wc -l | tr -d ' ')"
if [ "${KEPT:-0}" -gt 0 ] 2>/dev/null; then
  good "Kept $KEPT saved target(s)"
else
  note "No targets yet - pick a game in the WebUI after rebooting"
fi
good "Config folder : $CFG"

# ---------------------------------------------------------------- final
final() {
  T1="$(date +%s 2>/dev/null)" || T1=0
  EL=""
  if [ "$T0" -gt 0 ] 2>/dev/null && [ "$T1" -ge "$T0" ] 2>/dev/null; then
    EL="  ·  $((T1 - T0))s"
  fi
  ui_print "  ──────────────────────────────────"
  ui_print "   KOYRI STRETCH  $VER"
  ui_print "   Device   : ${MODEL:-unknown}"
  ui_print "   Android  : ${ANDROID:-?} (API ${SDK:-?})"
  ui_print "   Root     : $ROOT"
  ui_print "   Engine   : $LIBS_OK/2 libraries"
  ui_print "   Targets  : $KEPT saved"
  ui_print "   Ratios   : any NxM, 1..32 per side"
  ui_print "              (16:9 16:10 21:9 20:9 4:3 5:4 3:2 10:9 2:1 1:1"
  ui_print "               9:16 3:4  presets)"
  ui_print "  ──────────────────────────────────"
  ui_print "   READY$EL"
  ui_print "   1. Reboot"
  ui_print "   2. WebUI -> pick a game + ratio"
  ui_print "   3. Optional: touch remap, portrait stretch,"
  ui_print "      cutout flatten - per target"
  ui_print "   CLI   : sh stretch.sh add <pkg> 16x9"
  ui_print "           sh stretch.sh portrait <pkg> on"
  ui_print "   Check : sh check.sh"
  if [ -n "$CHANNEL_URL" ]; then
    ui_print "   Channel  : $CHANNEL_URL"
  fi
  ui_print "  ──────────────────────────────────"
  ui_print " "
}

if [ "$CAN_CLEAR" = "1" ]; then
  pause 0.5
  i=0
  while [ "$i" -lt 2 ]; do
    for f in '[-]' '[/]' '[|]' '[\]'; do
      clear
      ui_print " "
      ui_print "   $f  Widening the frame..."
      pause 0.1
    done
    i=$((i + 1))
  done
  clear
  banner
  final
else
  ui_print " "
  final
fi

# Hand the user to the channel after a successful flash -- the same shape the KOYRI
# 240FPS installer uses, because it is the one that has already flashed on real
# devices: detached, silent, and never part of an && / || chain.
#   * KOYRI_NO_CHANNEL=1 in the installer environment skips it (automation, CI)
#   * no `am` (recovery, minimal shell) skips it
#   * the pause keeps the installer's process group alive long enough for the binder
#     call to leave, and can never fail the install (`|| :`)
#   * no status is ever checked: a module that aborts a flash over a promo link is a
#     worse bug than a link that did not open
open_channel() {
  if [ "${KOYRI_NO_CHANNEL:-0}" = "1" ]; then return 0; fi
  if [ -z "$CHANNEL_URL" ]; then return 0; fi
  if ! command -v am >/dev/null 2>&1; then return 0; fi
  am start -a android.intent.action.VIEW -d "$CHANNEL_URL" >/dev/null 2>&1 &
  pause 0.5 || :
  return 0
}

open_channel
