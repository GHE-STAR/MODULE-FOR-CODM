#!/system/bin/sh
# KOYRI Stretch recovery CLI.
#
# The normal way to manage targets is the module WebUI in the root manager
# (KernelSU / KernelSU-Next / APatch / SukiSU / MMRL WebUI X). This script is
# only a terminal fallback for recovery or automation, and it writes the same
# files the WebUI writes.
#
#   sh stretch.sh add      <package> <ratio>        e.g. 16x9, 20x9, 1x1
#   sh stretch.sh touch    <package> on|off         off = leave raw input coords
#   sh stretch.sh portrait <package> on|off         on = stretch portrait windows too
#   sh stretch.sh cutout   <package> on|off         on = flatten DisplayCutout insets
#   sh stretch.sh remove   <package>
#   sh stretch.sh list

MODDIR=${0%/*}
DIR=${KS_CFG:-/data/adb/koyri_stretch}

usage() {
  echo "usage:"
  echo "  sh $0 add      <package> <ratio>       (NxM, 1..32 per side)"
  echo "  sh $0 touch    <package> on|off"
  echo "  sh $0 portrait <package> on|off"
  echo "  sh $0 cutout   <package> on|off"
  echo "  sh $0 remove   <package>"
  echo "  sh $0 list"
}

# Package names are used as file names under $DIR: keep them to the same
# charset and length limit the Zygisk companion and the WebUI enforce.
valid_pkg() {
  [ -n "$1" ] || return 1
  [ ${#1} -le 255 ] || return 1
  case "$1" in
    .*|*..*|*.|*[!A-Za-z0-9._]*) return 1 ;;
  esac
  case "$1" in
    *.*) ;;
    *) return 1 ;;
  esac
  return 0
}

# Any NxM with 1..32 per side. One rule for the whole module: the native parser,
# the WebUI and this CLI accept exactly the same shapes, so the presets are not a
# hard-coded allowlist anywhere.
valid_ratio() {
  case "$1" in
    *x*) ;;
    *) return 1 ;;
  esac
  a=${1%%x*}
  b=${1#*x}
  case "$a" in ''|*[!0-9]*|0*) return 1 ;; esac
  case "$b" in ''|*[!0-9]*|0*) return 1 ;; esac
  [ ${#a} -le 2 ] || return 1
  [ ${#b} -le 2 ] || return 1
  [ "$a" -ge 1 ] && [ "$a" -le 32 ] || return 1
  [ "$b" -ge 1 ] && [ "$b" -le 32 ] || return 1
  return 0
}

# Writes "<prefix><value>" into <dir>/<name> atomically. Never leaves a half-written
# file behind, so a crashed write cannot turn a target into junk on the next boot.
write_kv() {
  _file="$1"
  _prefix="$2"
  _value="$3"
  _tmp="$_file.tmp.$$"
  if ! printf '%s%s\n' "$_prefix" "$_value" > "$_tmp" 2>/dev/null; then
    rm -f "$_tmp"
    return 1
  fi
  chmod 644 "$_tmp" 2>/dev/null
  if [ -d "$_file" ]; then
    rm -f "$_tmp"
    return 1
  fi
  if ! mv -f "$_tmp" "$_file" 2>/dev/null; then
    rm -f "$_tmp"
    return 1
  fi
  return 0
}

require_pkg() {
  if ! valid_pkg "$1"; then
    echo "invalid package: $1" >&2
    exit 1
  fi
  mkdir -p "$DIR" || { echo "failed to create config directory: $DIR" >&2; exit 1; }
}

read_field() {
  sed -n "s/^$2//p" "$1" 2>/dev/null | head -n 1 | tr -d '\r'
}

case "$1" in
  add|set|ratio)
    pkg="$2"
    ratio="$3"
    if [ -z "$pkg" ] || [ -z "$ratio" ]; then usage; exit 1; fi
    if ! valid_ratio "$ratio"; then echo "invalid ratio: $ratio (NxM, 1..32 per side)"; exit 1; fi
    require_pkg "$pkg"
    if ! write_kv "$DIR/$pkg" "koyri.stretch=" "$ratio"; then
      echo "failed to save target: $pkg" >&2
      exit 1
    fi
    echo "OK: $pkg -> $ratio (force-stop and reopen the game)"
    ;;

  touch|portrait|cutout)
    pkg="$2"
    flag="$3"
    if [ -z "$pkg" ] || [ -z "$flag" ]; then usage; exit 1; fi
    case "$flag" in
      on) v=1 ;;
      off) v=0 ;;
      *) echo "invalid flag: $flag (on|off)"; exit 1 ;;
    esac
    require_pkg "$pkg"
    case "$1" in
      touch)    suffix=".koyri-touch";    prefix="koyri.touch=";    invert=1 ;;
      portrait) suffix=".koyri-portrait"; prefix="koyri.portrait="; invert=0 ;;
      *)        suffix=".koyri-cutout";   prefix="koyri.cutout=";   invert=0 ;;
    esac
    # The touch sidecar historically only existed for "off"; absence means remap on.
    # The other switches store the positive value, absence means off.
    if [ "$invert" = "1" ]; then
      if [ "$v" = "1" ]; then
        rm -f "$DIR/$pkg$suffix" 2>/dev/null
      elif ! write_kv "$DIR/$pkg$suffix" "$prefix" "0"; then
        echo "failed to save $1 switch: $pkg" >&2
        exit 1
      fi
    else
      if [ "$v" = "1" ]; then
        if ! write_kv "$DIR/$pkg$suffix" "$prefix" "1"; then
          echo "failed to save $1 switch: $pkg" >&2
          exit 1
        fi
      else
        rm -f "$DIR/$pkg$suffix" 2>/dev/null
      fi
    fi
    echo "OK: $pkg $1 $flag (force-stop and reopen the game)"
    ;;

  remove|rm|del)
    [ -n "$2" ] || { usage; exit 1; }
    if ! valid_pkg "$2"; then echo "invalid package: $2"; exit 1; fi
    if ! rm -f "$DIR/$2"; then
      echo "failed to remove target: $2" >&2
      exit 1
    fi
    # Drop the sidecars too, otherwise they would silently come back if the same
    # package is injected again later. .koyri-scale (downscale tile) and .koyri-fps
    # (frame-rate unlock) are leftovers from builds that still had those features,
    # swept here so they cannot linger.
    rm -f "$DIR/$2.koyri-scale" "$DIR/$2.koyri-touch" \
          "$DIR/$2.koyri-portrait" "$DIR/$2.koyri-cutout" "$DIR/$2.koyri-fps" 2>/dev/null
    echo "OK: removed $2"
    ;;

  list|ls)
    n=0
    for f in "$DIR"/*; do
      [ -f "$f" ] || continue
      name=${f##*/}
      case "$name" in
        .*) continue ;;
      esac
      r=$(read_field "$f" "koyri[.]stretch=")
      valid_ratio "$r" || continue
      t=$(read_field "$DIR/$name.koyri-touch" "koyri[.]touch=")
      [ "$t" = "0" ] || t=1
      p=$(read_field "$DIR/$name.koyri-portrait" "koyri[.]portrait=")
      [ "$p" = "1" ] || p=0
      c=$(read_field "$DIR/$name.koyri-cutout" "koyri[.]cutout=")
      [ "$c" = "1" ] || c=0
      echo "$name ratio=$r touch=$([ "$t" = "1" ] && echo on || echo off)" \
           "portrait=$([ "$p" = "1" ] && echo on || echo off)" \
           "cutout=$([ "$c" = "1" ] && echo on || echo off)"
      n=$((n + 1))
    done
    if [ "$n" -eq 0 ]; then echo "(no targets yet)"; fi
    exit 0
    ;;

  *)
    usage
    exit 1
    ;;
esac
