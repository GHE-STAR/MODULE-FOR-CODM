#!/system/bin/sh
# KOYRI Stretch uninstall.
#
# Removes the per-game targets/settings AND the runtime artefacts the module
# wrote into every targeted app's cache:
#
#   <app>/cache/.koyri/libpine_v2.so
#
# That file is chmod 0500 by the module, so an app that is later reinstalled
# keeps a stale copy until something deletes it. Doing it here means an
# uninstall really uninstalls, instead of leaving a hook library in every game
# that ever had a target.

CFG=/data/adb/koyri_stretch

if [ -d "$CFG" ]; then
  for f in "$CFG"/*; do
    [ -f "$f" ] || continue
    name=${f##*/}
    # Skip sidecars (.koyri-*) and dotfiles: the base name is the package.
    case "$name" in
      .*|*.koyri-*) continue ;;
    esac
    case "$name" in
      *[!A-Za-z0-9._]*) continue ;;
    esac
    # /data/user/* covers secondary users and work profiles; /data/data is the
    # user-0 alias on most builds.
    for dir in /data/user/*/"$name"/cache/.koyri /data/data/"$name"/cache/.koyri; do
      [ -d "$dir" ] && rm -rf "$dir" 2>/dev/null
    done
  done
fi

rm -rf /data/adb/koyri_stretch
