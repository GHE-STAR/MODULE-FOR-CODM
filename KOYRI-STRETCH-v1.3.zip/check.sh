#!/system/bin/sh
# KOYRI Stretch -- device compatibility check.
#
#   su -c 'sh /data/adb/modules/koyri_stretch/check.sh'
#
# Reports whether this device can run the module: architecture, the Zygisk
# library that will be loaded, the root manager / Zygisk state, the installed
# library integrity, the WebUI assets, and the configured per-game targets
# (ratio + the three per-target switches).
#
# The module is per-game: only packages listed in /data/adb/koyri_stretch are
# touched. Nothing here changes system settings.

MODDIR=${0%/*}
# Invoked as `sh check.sh` from inside the module dir, $0 carries no path, so
# ${0%/*} is the file name itself and every lookup below would report the module
# as missing. Fall back to the working directory, then to the manager roots.
[ -d "$MODDIR/zygisk" ] || MODDIR="$(pwd)"
if [ ! -d "$MODDIR/zygisk" ]; then
  for base in /data/adb/modules /data/adb/modules_update /data/adb/ksu/modules /data/adb/ap/modules; do
    if [ -d "$base/koyri_stretch/zygisk" ]; then MODDIR="$base/koyri_stretch"; break; fi
  done
fi
CFG=/data/adb/koyri_stretch

prop() { getprop "$1" 2>/dev/null; }

# Same rule as the native parser, the CLI and the WebUI: any NxM, 1..32 per side.
valid_ratio() {
  case "$1" in *x*) ;; *) return 1 ;; esac
  a=${1%%x*}
  b=${1#*x}
  case "$a" in ''|*[!0-9]*|0*) return 1 ;; esac
  case "$b" in ''|*[!0-9]*|0*) return 1 ;; esac
  [ ${#a} -le 2 ] && [ ${#b} -le 2 ] || return 1
  [ "$a" -ge 1 ] && [ "$a" -le 32 ] && [ "$b" -ge 1 ] && [ "$b" -le 32 ]
}

read_field() {
  sed -n "s/^$2//p" "$1" 2>/dev/null | head -n 1 | tr -d '\r'
}

echo "== KOYRI Stretch compatibility =="
echo "device   : $(prop ro.product.manufacturer) $(prop ro.product.model)"
echo "android  : $(prop ro.build.version.release) (SDK $(prop ro.build.version.sdk))"

# --- architecture: Zygisk loads zygisk/<abi>.so; the app process ABI decides
# --- which one. ro.product.cpu.abilist is comma separated; some ROMs only
# --- define the per-bitness lists or the single abi property.
abilist=$(prop ro.product.cpu.abilist | tr ',' ' ')
if [ -z "$abilist" ]; then
  abilist=$(prop ro.product.cpu.abilist64 | tr ',' ' ')
  abi32=$(prop ro.product.cpu.abilist32 | tr ',' ' ')
  [ -n "$abi32" ] && abilist="$abilist $abi32"
fi
[ -n "$abilist" ] || abilist=$(prop ro.product.cpu.abi)
abi=""
for a in $abilist; do
  case "$a" in
    arm64-v8a|armeabi-v7a) abi="$a"; break ;;
  esac
done
if [ -n "$abi" ]; then
  echo "arch     : $abi -> supported"
  # All shipped libraries are aligned for both, so either page size boots.
  pagesize=$(getconf PAGESIZE 2>/dev/null || true)
  case "$pagesize" in
    16384) echo "page     : 16 KB kernel -> supported (libs are 16 KB aligned)" ;;
    4096)  echo "page     : 4 KB kernel -> supported" ;;
    *)     echo "page     : ${pagesize:-unknown}" ;;
  esac
  if [ -f "$MODDIR/zygisk/$abi.so" ]; then
    echo "library  : zygisk/$abi.so -> present"
    if grep -q "koyri.stretch=" "$MODDIR/zygisk/$abi.so" 2>/dev/null; then
      echo "integrity: library looks intact"
    else
      echo "integrity: WARNING - library does not contain the expected marker"
    fi
    if grep -q "koyri.portrait=" "$MODDIR/zygisk/$abi.so" 2>/dev/null; then
      echo "build    : switches present (portrait / cutout / corrected touch origin)"
    else
      echo "build    : OLD binary - rebuild it, the sources are newer than this library"
    fi
  else
    echo "library  : zygisk/$abi.so -> MISSING (module not installed correctly)"
  fi
  echo "libs     : $(ls "$MODDIR/zygisk" 2>/dev/null | tr '\n' ' ')"
else
  echo "arch     : ${abilist:-unknown}"
  case "${abilist:-unknown}" in
    *x86*|*riscv64*) echo "           -> NOT supported (x86 emulators / Chromebooks / Android-x86 cannot run ARM-only libs)" ;;
    *) echo "           -> NOT supported (module ships arm64-v8a / armeabi-v7a only)" ;;
  esac
fi

# --- root manager ---
# SukiSU keeps the KernelSU daemon layout, so it has to be tested first;
# Magisk is checked last so a KernelSU device with a leftover /data/adb/magisk
# folder is not misreported.
mgr="none"
if [ -d /data/adb/suki ]; then
  mgr="SukiSU"
elif [ -d /data/adb/ksu ] || [ -d /data/adb/ksud ]; then
  mgr="KernelSU"
elif [ -d /data/adb/ap ] || [ -d /data/adb/apd ]; then
  mgr="APatch"
elif [ -d /data/adb/magisk ]; then
  mgr="Magisk"
fi
echo "root mgr : $mgr"

# --- zygisk ---
# Magisk keeps the switch in its settings db; older Magisk builds have no
# --sqlite, so fall back to the sqlite3 binary and report "unknown" rather
# than a wrong "off".
#
# On KernelSU/APatch, Zygisk comes from a module. The official Zygisk Next id
# is "zygisksu" (older builds used "zygisk_next" / "zygisknext"), ReZygisk uses
# "rezygisk". Managers also keep module dirs under their own prefix, not only
# /data/adb.
zproc=""
for p in zygiskd zygiskd64 zygiskd32 zygisk-ptrace64 zygisk-ptrace32 zygisk zygisk64 zygisk32; do
  if pidof "$p" >/dev/null 2>&1; then zproc="$p"; break; fi
done
zmod=""
for id in zygisksu zygisk_next zygisknext neozygisk rezygisk; do
  for base in /data/adb/modules /data/adb/modules_update /data/adb/ksu/modules /data/adb/ap/modules; do
    if [ -d "$base/$id" ]; then zmod="$base/$id"; break; fi
  done
  [ -n "$zmod" ] && break
done

if [ "$mgr" = "Magisk" ]; then
  v=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';" 2>/dev/null | tr -d '\r')
  if [ -z "$v" ] && [ -f /data/adb/magisk.db ]; then
    v=$(sqlite3 /data/adb/magisk.db "SELECT value FROM settings WHERE key='zygisk';" 2>/dev/null | tr -d '\r')
  fi
  case "$v" in
    1) z="on" ;;
    0) z="off" ;;
    *) z="unknown" ;;
  esac
  # Zygisk Next can replace the built-in implementation with the Magisk
  # switch off; report it instead of a misleading "off".
  if [ "$z" != "on" ]; then
    if [ -n "$zproc" ]; then
      z="running ($zproc)"
    elif [ -n "$zmod" ]; then
      if [ -f "$zmod/disable" ]; then z="disabled (${zmod##*/})"; else z="module present (${zmod##*/})"; fi
    fi
  fi
  echo "zygisk   : $z  (Magisk: Settings > Zygisk > Enabled)"
else
  if [ -n "$zproc" ]; then
    z="running ($zproc)"
  elif [ -n "$zmod" ]; then
    if [ -f "$zmod/disable" ]; then z="disabled (${zmod##*/})"; else z="module present (${zmod##*/})"; fi
  else
    z="not detected"
  fi
  echo "zygisk   : $z  (KernelSU/APatch: install Zygisk Next)"
fi

# --- module state ---
if [ -d "$MODDIR" ] && [ -f "$MODDIR/module.prop" ]; then
  echo "module   : installed at $MODDIR"
  echo "version  : $(read_field "$MODDIR/module.prop" 'version=')"
else
  echo "module   : NOT installed (flash the KOYRI-Stretch zip first)"
fi

# --- per-game targets ---
if [ -d "$CFG" ]; then
  n=0
  for f in "$CFG"/*; do
    [ -f "$f" ] || continue
    name=${f##*/}
    case "$name" in
      .*) continue ;;
    esac
    r=$(read_field "$f" "koyri[.]stretch=")
    valid_ratio "$r" || continue
    t=$(read_field "$CFG/$name.koyri-touch" "koyri[.]touch=")
    [ "$t" = "0" ] || t=1
    p=$(read_field "$CFG/$name.koyri-portrait" "koyri[.]portrait=")
    [ "$p" = "1" ] || p=0
    c=$(read_field "$CFG/$name.koyri-cutout" "koyri[.]cutout=")
    [ "$c" = "1" ] || c=0
    echo "target   : $name = $r  touch=$([ "$t" = "1" ] && echo on || echo off)  portrait=$([ "$p" = "1" ] && echo on || echo off)  cutout=$([ "$c" = "1" ] && echo on || echo off)"
    n=$((n + 1))
  done
  if [ "$n" -eq 0 ]; then
    echo "target   : (none yet -- add one from the module WebUI)"
  else
    echo "note     : stretch applies ONLY to the packages above"
  fi
else
  echo "target   : (no config dir yet)"
fi

# --- log ---
if [ -f "$CFG/module.log" ]; then
  echo "log      : $CFG/module.log ($(wc -c < "$CFG/module.log" 2>/dev/null | tr -d ' ') bytes)"
  [ -f "$CFG/module.log.old" ] && echo "log      : $CFG/module.log.old (previous generation)"
else
  echo "log      : (empty -- start a target once)"
fi

# --- WebUI (opened by the root manager, no background process) ---
if [ -f "$MODDIR/webroot/index.html" ] && [ -f "$MODDIR/webroot/js/app.js" ] \
   && [ -f "$MODDIR/webroot/js/core.js" ] && [ -f "$MODDIR/webroot/js/switches.js" ] \
   && [ -f "$MODDIR/webroot/css/style.css" ]; then
  echo "webui    : present (webroot/index.html)"
  echo "webui    : open the module page in KernelSU / KernelSU-Next / APatch / SukiSU / MMRL WebUI X"
  if [ "$mgr" = "Magisk" ]; then
    echo "webui    : Magisk has no built-in WebUI; use MMRL WebUI X or the recovery CLI"
  fi
else
  echo "webui    : MISSING (webroot assets are not installed)"
fi

echo "== done =="
exit 0
