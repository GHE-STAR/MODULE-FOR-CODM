#!/system/bin/sh
# Uperf WebUI backend (called from KernelSU WebUI: sh webui_api.sh ACTION VALUE PACKAGE WHICH)
MODDIR="${0%/*}/.."
PATH="$MODDIR/bin/busybox:$PATH"
USER_PATH="/sdcard/Android/yc/uperf"
ACTION="$1"; VALUE="$2"; PACKAGE="$3"; WHICH="$4"
case "$ACTION" in
  current)
    [ -f "$USER_PATH/cur_powermode.txt" ] && cat "$USER_PATH/cur_powermode.txt"
    ;;
  mode)
    case "$VALUE" in
      powersave|balance|performance|fast|auto)
        if [ -x /data/powercfg.sh ]; then
          sh /data/powercfg.sh "$VALUE" >/dev/null 2>&1
        else
          mkdir -p "$USER_PATH"
          printf '%s\n' "$VALUE" > "$USER_PATH/cur_powermode.txt"
        fi
        echo "OK"
        ;;
      pedestal)
        if [ -x /data/powercfg.sh ]; then
          sh /data/powercfg.sh pedestal >/dev/null 2>&1
        else
          mkdir -p "$USER_PATH"
          printf '%s\n' crazy > "$USER_PATH/cur_powermode.txt"
        fi
        echo "OK"
        ;;
      *) echo "Invalid power mode"; exit 1 ;;
    esac
    ;;
  packages)
    pm list packages -3 2>/dev/null | sed 's/^package://' | sort
    ;;
  apps)
    [ -f "$USER_PATH/perapp_powermode.txt" ] && cat "$USER_PATH/perapp_powermode.txt"
    ;;
  add|remove)
    case "$PACKAGE" in
      ''|*[!A-Za-z0-9._]*|.*|*.) echo "Invalid package name"; exit 1 ;;
    esac
    case "$PACKAGE" in *.*) ;; *) echo "Invalid package name"; exit 1 ;; esac
    mkdir -p "$USER_PATH"
    RULES="$USER_PATH/perapp_powermode.txt"
    [ -f "$RULES" ] || : > "$RULES"
    TMP="$RULES.webui.tmp"
    awk -v pkg="$PACKAGE" 'BEGIN{FS="[ \t]+"} /^[ \t]*#/ || NF==0 {print; next} $1!=pkg {print}' "$RULES" > "$TMP"
    if [ "$ACTION" = add ]; then
      case "$VALUE" in powersave|balance|performance|fast|crazy|auto) ;; *) rm -f "$TMP"; echo "Invalid app power mode"; exit 1 ;; esac
      printf '%s %s\n' "$PACKAGE" "$VALUE" >> "$TMP"
    fi
    chmod 0664 "$TMP"
    mv -f "$TMP" "$RULES"
    echo "OK"
    ;;
  log)
    case "$WHICH" in
      uperf) FILE="$USER_PATH/uperf_log.txt" ;;
      init) FILE="$USER_PATH/initsvc.log" ;;
      *) echo "Unknown log"; exit 1 ;;
    esac
    if [ -f "$FILE" ]; then tail -n 500 "$FILE"; else echo "Log file not created yet."; fi
    ;;
  clear)
    case "$WHICH" in
      uperf) FILE="$USER_PATH/uperf_log.txt" ;;
      init) FILE="$USER_PATH/initsvc.log" ;;
      *) echo "Unknown log"; exit 1 ;;
    esac
    : > "$FILE"
    chmod 0664 "$FILE"
    echo "OK"
    ;;
  restart)
    . "$MODDIR/script/libuperf.sh" 2>/dev/null
    (uperf_stop; sleep 1; uperf_start) >/dev/null 2>&1
    echo "OK"
    ;;
  *) echo "Unknown action"; exit 1 ;;
esac
